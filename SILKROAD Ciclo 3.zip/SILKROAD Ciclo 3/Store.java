import java.util.ArrayList;

/**
 * Representa una tienda dentro del simulador Silk Road.
 * 
 * Cada tienda tiene una ubicación, una cantidad de tenges (moneda del juego),
 * una representación gráfica compuesta por un rectángulo (cuerpo) y un triángulo (techo),
 * y puede ser recolectada, reiniciada, movida gráficamente y cambiar de color.
 * 
 * @author Juan Camilo Lizarazo
 * @version 1.0
 */
public class Store implements Unit{
    private int location;
    private int tenges;
    private int initialTenges;
    private String initialColor;
    private String actualColor;
    private Rectangle box;
    private Triangle rooft;
    private int emptiedCount;
    private ArrayList<Figura> parts;
    
    /**
     * Crea una tienda en una ubicación específica con una cantidad inicial de tenges.
     * 
     * @param location Posición de la tienda en la ruta.
     * @param tenges Cantidad inicial de tenges disponibles en la tienda.
     */

    public Store(int location, int tenges) {
        this.location = location;
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.initialColor = "";
        this.actualColor = "";
        this.box = new Rectangle();
        box.changeSize(30, 100);
        box.moveHorizontal(75);
        box.moveVertical(50);
        this.rooft = new Triangle();
        rooft.changeSize(50, 100);
        rooft.moveHorizontal(125);
        rooft.moveVertical(0);
        this.parts = new ArrayList<>();
        parts.add(this.rooft);
        parts.add(this.box);
        
    }
    
    /**
     * Cambia el color gráfico de la tienda.
     * 
     * @param color Nuevo color a aplicar.
     */

    public void changeColor(String color){
    for (Figura f : parts){
        f.changeColor(color);
    }
    actualColor = color;
    }
    
    /**
     * Mueve gráficamente la tienda a una posición en la cuadrícula.
     * 
     * @param row Fila en la cuadrícula.
     * @param col Columna en la cuadrícula.
     */

    public void graphicMove(int row, int col){
    box.moveHorizontal(75+250*col);
    box.moveVertical(50+250*row);
    rooft.moveHorizontal(125+250*col);
    rooft.moveVertical(250*row);
    }
    

    /**
     * Hace visible la tienda en el lienzo.
     */

    @Override
    public void makeVisible() {
    for (Figura f : parts){
        f.makeVisible();
    }
    }
    
    /**
     * Oculta la tienda del lienzo.
     */

    @Override
    public void makeInvisible() {
    for (Figura f : parts){
        f.makeInvisible();
    }
    }
    
    /**
     * Obtiene la ubicación actual de la tienda.
     * 
     * @return Posición en la ruta.
     */

    public int getLocation() { 
        return location; 
    }
    

    /**
     * Obtiene la cantidad actual de tenges disponibles en la tienda.
     * 
     * @return Cantidad de tenges.
     */

    public int getTenges() { 
        return tenges; 
    }
    
    /**
     * Reinicia la tienda a su estado original (color y tenges).
     */
    public void reset() {
        changeColor(initialColor);
        this.tenges = initialTenges; 
    }
    
    
    /**
     * Recolecta todos los tenges de la tienda y la marca como vacía.
     * 
     * @return Cantidad de tenges recolectados.
     */

    public int collect() {
        changeColor("black");
        int amount = tenges;
        tenges = 0;
        emptiedCount++;
        return amount;
    }
    
    /**
     * Devuelve el número de veces que la tienda ha sido desocupada.
     * 
     * @return Número de veces que se ha recolectado todo de la tienda.
     */
    public int getEmptiedCount() {
    return emptiedCount;
    }
    
    /**
     * Obtiene el color actual de la tienda.
     * 
     * @return Color actual.
     */

    public String getActualColor(){
        return actualColor;
    }
    
    /**
     * Establece el color inicial de la tienda (usado para reiniciar).
     * 
     * @param color Color inicial.
     */
    public void setInitialColor(String color){
        initialColor = color;
    }
    
}
