import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
/**
 * Clase principal que inicia el simulador Silk Road en distintos modos.
 * 
 * El usuario puede elegir entre:
 * - Interfaz sin gráficos (modo consola interactiva).
 * - Interfaz con gráficos.
 * - Consola para maratón normal.
 * - Consola para maratón lenta.
 * 
 * También se valida que el tamaño del tablero sea mayor a cero.
 * 
 * @author Juan Camilo Lizarazo
 * @version 1.0
 */

public class Main {
    /**
     * Método principal que lanza el simulador Silk Road.
     * Solicita al usuario el tamaño del tablero y el modo de simulación.
     */
    public static void main() {
        int length = Integer.parseInt(
            JOptionPane.showInputDialog("Nota: Si desea usar la interfaz de maraton no importa el tamaño del tablero este se calculara\nIngrese el tamaño de la ruta (número de posiciones):")
        );
        if (length == 0){
            JOptionPane.showMessageDialog(null, "⚠No existen tableros de longitud 0⚠\nSaliendo...");
            System.exit(0);
        }
        SilkRoad game = new SilkRoad(Math.abs(length));
        

        String modo = JOptionPane.showInputDialog(
            "Seleccione modo:\n1. Interfaz sin graficos\n2. Interfaz con graficos\n3. Consola para maratón normal\n4.Consola para maratón lenta"
        );
        
        if ("1".equals(modo)) {
            MainConsole.start(game);
        } else if ("2".equals(modo)) {
            MainGraphics.start(game);
        } else if ("3".equals(modo)) {
            MarathonConsole.start(false);
        } else if ("4".equals(modo)) {
            MarathonConsole.start(true);
        } else {
            JOptionPane.showMessageDialog(null, "Opción inválida, saliendo...");
            System.exit(0);
        }
    }
}