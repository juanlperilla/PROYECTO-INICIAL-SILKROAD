import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;



public class SilkRoadContest{
    
    /**
     * Resuelve la simulación de ganancias día a día en el juego SilkRoad.
     * 
     * Por cada día:
     * - Si el tipo es 1, se agrega un robot en una posición.
     * - Si el tipo es 2, se agrega una tienda con ubicación y ganancia.
     * - Luego, los robots se mueven hacia las tiendas buscando maximizar ganancias.
     * - Se repite mientras algún robot pueda seguir ganando.
     * 
     * @param days Arreglo de días, donde cada día contiene una acción (robot o tienda).
     * @return Arreglo con la ganancia acumulada al final de cada día.
     */
       public static int[] solve(int[][] days) {
        List<Integer> robots = new ArrayList<>();
        List<int[]> stores = new ArrayList<>();

        for (int[] line : days) {
            if (line[0] == 1) {
                robots.add(line[1]);
            } else {
                stores.add(new int[]{line[1], line[2]});
            }
        }

        int[] profit = new int[robots.size()];
        boolean moved;

        do {
            moved = false;

            for (int i = 0; i < robots.size(); i++) {
                int current = robots.get(i);
                int bestStoreIndex = -1;
                int bestGain = 0;


                for (int j = 0; j < stores.size(); j++) {
                    int sLoc = stores.get(j)[0];
                    int sTenges = stores.get(j)[1];
                    if (sTenges <= 0) continue;

                    int gain = sTenges - Math.abs(sLoc - current);
                    if (gain > bestGain) {
                        bestGain = gain;
                        bestStoreIndex = j;
                    }
                }

            
                if (bestStoreIndex == -1 || bestGain <= 0) continue;

        
                int bestLoc = stores.get(bestStoreIndex)[0];
                robots.set(i, bestLoc);
                profit[i] += bestGain;
                stores.get(bestStoreIndex)[1] = 0;

                moved = true;
            }

        } while (moved);

        return profit;
    }




    
    /**
     * Simula visualmente el juego SilkRoad día a día.
     * 
     * Por cada día:
     * - Coloca robots o tiendas según el tipo de evento.
     * - Ejecuta el movimiento de los robots.
     * - Muestra la ganancia acumulada.
     * - Reinicia el estado visual para el siguiente día.
     * 
     * @param days Arreglo de días con eventos.
     * @param slow Si es true, se activa el movimiento lento visual.
     */
    public static void simulate(int[][] days, boolean slow) {

    SilkRoad game = new SilkRoad(days);
    game.makeVisible();

    int[] results = solve(days);
    
    for (int i = 0; i < days.length; i++) {
        int[] day = days[i];
        int type = day[0];

        if (type == 1) {
            game.placeRobot(day[1]);
        } else if (type == 2) {
            game.placeStore(day[1], day[2]);
        }
        if (slow){ 
        game.moveRobotsSlow();
        }
        game.moveRobots();
        System.out.println(game.getProfit());
        game.reboot();
    }
    return;
    }
    
    
}   
