
/**
 * Write a description of interface Unit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface Unit
{
    /**
     * Make this unit visible. If it was already visible, do nothing.
     */
    void makeVisible();
    

    /**
     * Make this triangle invisible. If it was already invisible, do nothing.
     */
     void makeInvisible();
    
    
}