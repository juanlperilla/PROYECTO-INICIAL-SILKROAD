import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
/**
 * A circle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 1.0.  (15 July 2000) 
 */

public class Circle extends Figura{
    public static final double PI=3.1416;
    private int diameter;

    public Circle() {
        super();
        diameter = 100;
    }
    
    @Override
    protected void draw(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, 
                new Ellipse2D.Double(xPosition, yPosition, 
                diameter, diameter));
            canvas.wait(10);
        }
    }
    
    @Override  
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    @Override
    public void makeInvisible(){
        erase();
        isVisible = false;
    }

    public void changeSize(int newDiameter){
        erase();
        diameter = newDiameter;
        draw();
    }
    
    public  double area(){
        double resultado = Math.pow(diameter/2.0, 2)* PI; 
        return resultado;
        
    }
    
    public void bigger(int percentage){ 
        
        if((percentage < 0) || (percentage > 100)){
            System.out.println("porcentaje invalido");
            return;
            
        }
        double resultado1 = Math.sqrt(1 + percentage / 100.0);
        int newDiameter= (int)(diameter * resultado1);
        System.out.println("El nuevo diametro es :" + newDiameter);
        
        changeSize(newDiameter);
        System.out.println("Área: " + area());
        
        
    }

    public void changeSizeArea(int newArea){
        if (newArea <= 0) return;
        int radio = (int)Math.round(Math.sqrt(newArea/PI));
        int diametro = radio * 2;
        changeSize(diametro);
        
        }
    
}
