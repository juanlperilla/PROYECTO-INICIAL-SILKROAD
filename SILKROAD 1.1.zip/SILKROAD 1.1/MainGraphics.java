
/**
 * Write a description of class MainGraphics here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class MainGraphics {
    public static void start(SilkRoad game) {
        game.makeVisible();
        MainConsole.start(game);
    }
}