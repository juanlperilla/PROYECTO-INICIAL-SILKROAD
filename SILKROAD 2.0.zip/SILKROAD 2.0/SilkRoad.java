/**
 * Creates the environment requirements for silkroad with Robots.
 * 
 * @author (Juan Camilo Lizarazo- Juan Angel Salas) 
 * @version (1.0)
 */

import java.util.*;
import java.util.Random;
import java.util.Collections;
import java.util.Queue;

/**
 * Clase que manjea la soperaciones apara el simulador de SilkRoad
 *  */
public class SilkRoad {
    private int length;
    private List<Store> stores;
    private List<Robot> robots;
    private int profit;
    private boolean lastOperationOk;
    private Board board;
    private boolean showing;
    private ProgressBar bar;
    private int maximumTenge;
    private List<String> availableColors;
    private Queue<Robot> robotMovements;
    
    
    /**
     * Crea una ruta y un tablero de loingitud lenght
     *
     * @param lenght tamaño de la ruta 
     */
    public SilkRoad(int length) {
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.robotMovements = new ArrayDeque<>();
        this.profit = 0;
        this.lastOperationOk = true;
        this.showing = false;
        this.maximumTenge = 1;
        this.availableColors = new ArrayList<>();
        Collections.addAll(availableColors,
                "red", "blue", "yellow", "green", "magenta",
                "orange", "pink", "cyan", "gray", "light_gray", "dark_gray",   
                "brown", "gold", "lime", "teal", "navy", "salmon",               
                "orchid", "coral", "aquamarine", "turquoise", "alice_blue",      
                "crimson", "deep_pink", "chartreuse"                              
        );
        double n = Math.sqrt(length);
        int z = (int) Math.ceil(n);
        board = new Board(z);
        bar = new ProgressBar(1500, 50, 250, 100);     
        
    }
    /**
     * Grafica la ruta  
     */
    public void makeVisible(){
        board.makeVisible();
        bar.makeVisible();
        for (Store s : stores) {
            s.makeVisible();
        }
        for (Robot r : robots) {
            r.makeVisible();
        }
        showing = true;
    }
    /**
     * Oculta la ruta 
     */
    public void makeInvisible(){
        board.makeInvisible();
        bar.makeInvisible();
        for (Store s : stores) {
            s.makeInvisible();
            }
        for (Robot r : robots) {
            r.makeInvisible();
        }
    }
    /**
     * Intenta colocar una tienda en la ubicación dada.
     * Si ya existe una tienda en esa posición o la localización es inválida,
     * la operación falla y no se crea la tienda. Y si se esta mostrando se actualiza el grafico.
     *
     * @param location índice de la localización donde se intentará crear la tienda.
     * @param tenges cantidad inicial de monedas que contendrá la tienda.
     */
    public void placeStore(int location, int tenges) {
        if (location >= length|| location < 0) {
            lastOperationOk = false;
            return;
        }
        for (Store s : stores) {
            if (s.getLocation() == location) {
                lastOperationOk = false;
                return;
            }
        }
        Store newstore = new Store(location, tenges);
        int[] cords = positionToCoords(location, this.length); 
        newstore.graphicMove(cords[0], cords[1]);
        newstore.changeColor(randomColor());
        newstore.setInitialColor(newstore.getActualColor());
        stores.add(newstore);
        stores.sort(Comparator.comparingInt(Store::getLocation));
        maximumTenge += tenges;
        for (Robot r : robots) {
                    if (r.getLocation() == location && newstore.getTenges() > 0) {
                        int collected = newstore.collect();
                        int distance = Math.abs(r.getInitialLocation() - newstore.getLocation());
                        int gain = collected - distance;
                        profit += gain;
                        r.addGain(location, Math.max(gain, 0));
                        bar.update(gain, maximumTenge);
            }
        }
        if (showing) {
            newstore.makeVisible();
            bar.update(profit, maximumTenge);
        }
        lastOperationOk = true;
    }
    /**
     * Busca y elimina una tienda.
     *
     * @param location localización de la tienda.
     */
    public void removeStore(int location) {
        boolean removed = stores.removeIf(s -> {
            if (s.getLocation() == location){
                s.makeInvisible();
                s.reset();
                maximumTenge -= s.getTenges();
                bar.update(profit, maximumTenge);
                return true;
        }
        return false;
        });
        lastOperationOk = removed;
    }
    /**
     * Reinicia las monedas en todas las tiendas.
     *
     */
    public void resupplyStores() {
        for (Store s : stores) {
            s.reset();
        }
        lastOperationOk = true;
    }

    /**
     * Intenta colocar un Robot en la ubicación dada.
     * Si ya existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se crea el Robot. Y si se esta mostrando se actualiza el grafico.
     *
     * @param location índice de la localización donde se intentará crear el Robot.
     */
    public void placeRobot(int location) {
        if (location >= this.length || location < 0) {
            lastOperationOk = false;
            return;
        }
        for (Robot r : robots) {
            if (r.getInitialLocation() == location) {
                lastOperationOk = false;
                return;
                
            }
        }
        Robot newrobot = new Robot(location);
        for (Store s : stores) {
                    if (s.getLocation() == location && s.getTenges() > 0) {
                        int collected = s.collect();
                        int distance = Math.abs(newrobot.getInitialLocation() - s.getLocation());
                        int gain = collected - distance;
                        newrobot.addGain(location, Math.max(gain, 0));
                        profit += gain;
            }
        }
        int[] cords = positionToCoords(location, this.length);
        newrobot.graphicMove(cords[0], cords[1]);
        newrobot.changeColor(randomColor());
        robots.add(newrobot);
        robotMovements.offer(newrobot);
        robots.sort(Comparator.comparingInt(Robot::getLocation));
        if (showing) {
            newrobot.makeVisible();
            bar.update(profit, maximumTenge);
        }
        lastOperationOk = true;
    }
    /**
     * Busca un Robot en la ubicación dada y lo elimina.
     * Si no existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se elimina ningun Robot.
     *
     * @param location índice de la localización donde se intentará eliminar robot.
     */
    public void removeRobot(int location) {
        boolean removed = robots.removeIf(r -> {
            if (r.getLocation() == location){
                r.makeInvisible();
                return true;
        }
        return false;
        });
        lastOperationOk = removed;
    }
    
    /**
     * Busca un Robot en la ubicación dada y lo mueve.
     * Si no existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se mueve ningun Robot.
     *
     * @param location índice de la localización del Robot que se intentará mover.
     * @param meters cantidad de casillas que avanzara el robot
     */
    public void moveRobot(int location, int meters) {
        if (location + meters >= length || location + meters < 0) {
            lastOperationOk = false;
            return;
        }
        for (Robot r : robotMovements) {
            if (r.getLocation() == location) {
                int finallocation = location + meters;
                int[] cords = positionToCoords(finallocation, this.length);
                r.graphicMove(cords[0], cords[1]);
                r.move(meters);
                
                for (Store s : stores) {
                    if (s.getLocation() == r.getLocation() && s.getTenges() > 0) {
                        int collected = s.collect();
                        int distance = Math.abs(r.getInitialLocation() - r.getLocation());
                        int gain = collected - distance;
                        profit += Math.max(gain, 0);
                        r.addGain(location, Math.max(gain, 0));
                        bar.update(profit, maximumTenge);
                    }
                }
                lastOperationOk = true;
                return;
            }
        }
        lastOperationOk = false;
        }
        
    public void moveRobotOptimized(int location) {
        if (location >= length || location < 0) {
            lastOperationOk = false;
            return;
        }
        for (Robot r : robotMovements) {
            if (r.getLocation() == location) {
                int meters = r.calculateBestMove(stores);
                int finallocation = location + meters;
                int[] cords = positionToCoords(finallocation, this.length);
                r.graphicMove(cords[0], cords[1]);
                r.move(meters);
                
                for (Store s : stores) {
                    if (s.getLocation() == r.getLocation() && s.getTenges() > 0) {
                        int collected = s.collect();
                        int distance = Math.abs(location - r.getLocation());
                        int gain = collected - distance;
                        profit += Math.max(gain, 0);
                        r.addGain(location, Math.max(gain, 0));
                        bar.update(profit, maximumTenge);
                    }
                }
                lastOperationOk = true;
                return;
            }
        }
        lastOperationOk = false;
        }
    
    /**
     * Todos los Robots que se hayan creados vuelven a su posicion de origen (donde fueron creados).
     *
     */
    public void returnRobots() {
        for (Robot r : robots) {
            int[] cords = positionToCoords(r.getInitialLocation(), length);
            r.graphicMove(cords[0], cords[1]);
            r.reset();
        }
        lastOperationOk = true;
    }
    /**
     * Todos los Robots que se hayan creados vuelven a su posicion de origen (donde fueron creados), las tiendas se reabastecen (Se reinicia el tenge) y se reinicia el profit (profit = 0).
     *
     */ 
    public void reboot() {
        resupplyStores();
        returnRobots();
        profit = 0;
        bar.update(profit, maximumTenge);
        lastOperationOk = true;
    }
    
    /**
     * Todos los Robots que se hayan creados vuelven a su posicion de origen (donde fueron creados), las tiendas se reabastecen (Se reinicia el tenge) y se mantiene el profit.
     *
     */ 
    public void newDay(){
        resupplyStores();
        returnRobots();
        lastOperationOk = true;
    }
    
    /**
     * Termina la simulacion, oculta el tablero y  finaliza la Máquina Virtual de Java terminando la ejecución del programa.
     *
     */ 
    public void finish() {
        makeInvisible();
        System.exit(0);
    }

    /**
     * Devuelve el profit
     *
     */ 
    public int getProfit() {
        return profit;
    }
    /**
     * Contruye una matriz bidimensional de enteros que representa una lista de tiendas donde arr[i][0] es la localizacion de la tienda y arr[i][1] es el tenge de dicha tienda.
     * @return arr la matriz creada.
     */
    public int[][] stores() {
        int[][] arr = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            arr[i][0] = stores.get(i).getLocation();
            arr[i][1] = stores.get(i).getTenges();
        }
        return arr;
    }
    
    /**
     * Contruye una matriz bidimensional de enteros que representa una lista de robots donde arr[i][0] es la localizacion de origen del Robot y arr[i][1] es el localizacion actual del Robot.
     * @return arr la matriz creada.
     */
    public int[][] robots() {
        int[][] arr = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            arr[i][0] = robots.get(i).getInitialLocation();
            arr[i][1] = robots.get(i).getLocation();
        }
        return arr;
    }
    
    /**
     * Evalua si la ultima operacion fue correcta.
     * @return lastOperationOk si el valor es verdadero fue correcto si es falso es invalido.
     */

    public boolean ok() {
        return lastOperationOk;
    }
    
    /**
     * Convierte una localizacion lineal a cordenadas de una matriz recorriendo en forma de espiral cuadrada.
     * @param location localización que se quiere encontrar en la espiral.
     * @param length tamaño total de la espiral.
     * @return int[]{x, y} devuelve las cordenadas en cordenadas de matriz.
     * @return null devuelve si no se pudo encontrar la ubicacion.
     */
    public int[] positionToCoords(int location, int length) {
        int n = (int) Math.ceil(Math.sqrt(length));
        int[][] board = new int[n][n];
        
        
        int[] dx = {0, 1, 0, -1};
        int[] dy = {1, 0, -1, 0};
        int dir = 0;
        
        int x = 0, y = 0;
        boolean[][] visited = new boolean[n][n];
        
        for (int k = 0; k < length; k++) {
            board[x][y] = k;
            if (k == location) {
                return new int[]{x, y};
            }
            visited[x][y] = true;
            
            int nx = x + dx[dir], ny = y + dy[dir];
            if (nx < 0 || nx >= n || ny < 0 || ny >= n || visited[nx][ny]) {
                dir = (dir + 1) % 4;
                nx = x + dx[dir];
                ny = y + dy[dir];
            }
            x = nx; y = ny;
        }
        return null;
    }
    
    /**
     * Genera un color valido y aleatorio para shapes.
     * @return color devuelve el color generado.
     */
    public String randomColor() {
        if (availableColors.isEmpty()) {
            Collections.addAll(availableColors,
                "red", "blue", "yellow", "green", "magenta",
                "orange", "pink", "cyan", "gray", "light_gray", "dark_gray",
                "brown", "gold", "lime", "teal", "navy", "salmon",
                "orchid", "coral", "aquamarine", "turquoise", "alice_blue",
                "crimson", "deep_pink", "chartreuse");
        }
        Random random = new Random();
        int index = random.nextInt(availableColors.size());
        String color = availableColors.get(index);
        availableColors.remove(index);

        return color;
    }
    
    public int timesStoreEmptied(int location) {
    for (Store s : stores) {
        if (s.getLocation() == location) {
            lastOperationOk = true;
            return s.getEmptiedCount();
        }
    }
    lastOperationOk = false;
    return -1;
    
    }  
    
    public List<Tupla> especificRobotGains(int location){
        for (Robot r: robots){
            if (r.getLocation() == location){
                lastOperationOk = true;
                return r.getGains();
            }
        }
        lastOperationOk = false;
        return null;
    }
    
    public void loadFromMarathonInput(List<String> events) {
    for (String line : events) {
        String[] parts = line.split(" ");
        int type = Integer.parseInt(parts[0]);
        if (type == 1) { 
            int location = Integer.parseInt(parts[1]);
            placeRobot(location);
            for (Robot r : robots) {
            moveRobotOptimized(r.getLocation());
            }
            System.out.println(getProfit());
        }
        else if (type == 2) {
            int location = Integer.parseInt(parts[1]);
            int tenges = Integer.parseInt(parts[2]);
            placeStore(location, tenges);
            for (Robot r : robots) {
            moveRobotOptimized(r.getLocation());
            }
        
            System.out.println(getProfit());
        }
                
        newDay();
    }
    }
}