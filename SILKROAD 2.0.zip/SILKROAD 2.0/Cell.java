
/**
 * Creates a graphic cell that can change color.
 *
 * 
 * @author  (Juan Camilo Lizarazo) 
 * @version (1.0)
 */

import java.util.ArrayList;
import java.util.List;
public class Cell {
    private int y;
    private int x;
    private String color;   
    private Rectangle box;
    private Rectangle border;
    
    public static final int SIZE = 250;
    public static final int MARGIN = Math.round(SIZE*0.016f);
    
    public Cell(String color, int x, int y) {
        this.color = color;
        this.x = x;
        this.y =y;
        
        border = new Rectangle();
        border.changeSize(SIZE, SIZE);
        border.changeColor("black");
        border.moveHorizontal(x);
        border.moveVertical(y);
        
        box = new Rectangle();
        box.changeSize(SIZE - MARGIN, SIZE - MARGIN);
        box.changeColor(color);
        box.moveHorizontal(x+MARGIN/2);
        box.moveVertical(y+MARGIN/2);
    }
    
    public void changeSize(int newSize){
        int MARGIN = Math.round(newSize*0.016f);
        border.changeSize(newSize, newSize);
        box.changeSize(newSize - MARGIN, newSize - MARGIN);
        box.moveHorizontal(this.x+MARGIN/2);
        box.moveVertical(this.y+MARGIN/2);
    }

    public void makeVisible() {
        border.makeVisible();
        box.makeVisible();
    }

    public void makeInvisible() {
        border.makeInvisible();
        box.makeInvisible();
    }

    
    public String getColor() {
        return color;
    }
    
    public int getSize() {
        return SIZE;
    }
    
    public void setColor(String newColor) {
    this.color = newColor;
    box.changeColor(newColor); 
    box.makeVisible();
    }
    
    
}