
/**
 * A class for saving tuples on arrays or containers like in python.
 * 
 * @author (Juan Camilo Lizarazo) 
 * @version (a version number or a date)
 */
public class Tupla {
    private int fir;
    private int sec;

    public Tupla(int first, int second) {
        this.fir = first;
        this.sec = second;
    }
    
    public int getFirst(){
        return fir;
    }
     public int getSecond(){
         return sec;
    }
}
