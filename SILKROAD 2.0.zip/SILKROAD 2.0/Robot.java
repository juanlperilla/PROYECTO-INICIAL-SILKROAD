import java.util.*;


/**
 * A class that contains Robot methods for silkroad.
 * 
 * @author (Juan Camilo Lizarazo) 
 * @version (1.0)
 */
public class Robot {
    private int initialLocation;
    private int currentLocation;
    private List<Tupla> gains;
    // Cuerpo grafico del robot
    private Circle head;
    private Rectangle neck;
    private Rectangle body;
    private Rectangle lefthand;
    private Rectangle righthand;
    private Rectangle leftleg;
    private Rectangle rightleg;
    public Robot(int location) {
        this.initialLocation = location;
        this.currentLocation = location;
        this.gains = new ArrayList<>();
        head = new Circle();
        head.changeSize(50);
        head.moveHorizontal(98);
        head.moveVertical(90);
        neck = new Rectangle();
        neck.changeSize(15,10);
        neck.moveHorizontal(118);
        neck.moveVertical(140);
        body = new Rectangle();
        body.changeSize(50, 60);
        body.moveHorizontal(95);
        body.moveVertical(147);
        lefthand = new Rectangle();
        lefthand.changeSize(50, 10);
        lefthand.moveHorizontal(85);
        lefthand.moveVertical(155);
        righthand = new Rectangle();
        righthand.changeSize(50, 10);
        righthand.moveHorizontal(155);
        righthand.moveVertical(155);
        leftleg = new Rectangle();
        leftleg.changeSize(50, 10);
        leftleg.moveHorizontal(130);
        leftleg .moveVertical(180);
        rightleg = new Rectangle();
        rightleg.changeSize(50, 10);
        rightleg.moveHorizontal(110);
        rightleg .moveVertical(180);
        changeColor("blue");
    }
    
    public void changeColor(String color){
    head.changeColor(color);
    neck.changeColor(color);
    body.changeColor(color);
    lefthand.changeColor(color);
    righthand.changeColor(color);
    leftleg.changeColor(color);
    rightleg.changeColor(color);
    }
    
    public void graphicMove(int row, int col){
    head.moveHorizontal(98+250*col);
    head.moveVertical(90+250*row);
    neck.moveHorizontal(118+250*col);
    neck.moveVertical(140+250*row);
    body.moveHorizontal(95+250*col);
    body.moveVertical(147+250*row);
    lefthand.moveHorizontal(85+250*col);
    lefthand.moveVertical(155+250*row);
    righthand.moveHorizontal(155+250*col);
    righthand.moveVertical(155+250*row);
    leftleg.moveHorizontal(130+250*col);
    leftleg.moveVertical(180+250*row);
    rightleg.moveHorizontal(110+250*col);
    rightleg.moveVertical(180+250*row);
    }
    public void makeVisible() {
        head.makeVisible();
        neck.makeVisible();
        body.makeVisible();
        lefthand.makeVisible();
        righthand.makeVisible();
        leftleg.makeVisible();
        rightleg.makeVisible();
    }
    
    public void makeInvisible() {
        head.makeInvisible();
        neck.makeInvisible();
        body.makeInvisible();
        lefthand.makeInvisible();
        righthand.makeInvisible();
        leftleg.makeInvisible();
        rightleg.makeInvisible();
    }
    public int getLocation() { 
        return currentLocation; 
    }
    
    public int getInitialLocation() { 
        return initialLocation; 
    }

    public void reset() {
        this.currentLocation = initialLocation;
    }

    public void move(int meters) {
        currentLocation += meters;
    }
    //Ciclo nose
    public void addGain(int locationwhereitwasgain, int gain) {
    Tupla locyg = new Tupla(locationwhereitwasgain, gain);
    gains.add(locyg);
    }

    public List<Tupla> getGains() {
    return gains;
    }
    
    public int calculateBestMove(List<Store> stores) {
    int bestMove = 0;
    int bestGain = Integer.MIN_VALUE;
    
    for (Store s : stores) {
        if (s.getTenges() > 0) {
            int distance = Math.abs(currentLocation - s.getLocation());
            int gain = s.getTenges() - distance;
            
            if (gain > bestGain) {
                bestGain = gain;
                bestMove = s.getLocation() - currentLocation; 

            }
        }
    }
    return bestMove;
    }
    
}