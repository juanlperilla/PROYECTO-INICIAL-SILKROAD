
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main() {
        int length = Integer.parseInt(
            JOptionPane.showInputDialog("Ingrese el tamaño de la ruta (número de posiciones):")
        );
        SilkRoad game = new SilkRoad(length);

        String modo = JOptionPane.showInputDialog(
            "Seleccione modo:\n1. Interfaz sin graficos\n2. Interfaz gráfica\n3. Entrada maratón"
        );
        
        if ("1".equals(modo)) {
            MainConsole.start(game);
        } else if ("2".equals(modo)) {
            MainGraphics.start(game);
        } else if ("3".equals(modo)) {
            MarathonConsole.start(game);
        } else {
            JOptionPane.showMessageDialog(null, "Opción inválida, saliendo...");
        }
    }
}

