
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests for SilkRoad project
 * 
 * @author Juan Camilo Lizarazo -Jua Angel Salas
 * @version 1.0
 */
public class SilkRoadC2Test {

    private SilkRoad road;

        @Before
    public void setUp() {
        road = new SilkRoad(50);
        road.makeInvisible();
    }
    /**
     * Debería crear una tienda válida en una posición libre y dentro de rango.
     *
     */
    @Test
    public void accordingJLShouldPlaceStoreCorrectlyWhenLocationValid(){
        road.placeStore(0, 20);
        assertTrue("Se debio crear una tienda en 0", road.ok());
        assertEquals("Ahora hay una tienda en la lista", 1, road.stores().length);
    }
    
    /**
     * No debería permitir colocar una tienda fuera de los límites del tablero (location >= length).
     *
     */
    @Test
    public void accordingJLShouldNotPlaceStoreOutsideBounds() {
        road.placeStore(60, 20);
        assertFalse("No debería permitir colocar tienda fuera de la ruta", road.ok());
        assertEquals("No debe haberse creado ninguna tienda", 0, road.stores().length);
        }
    /**
     * No debería permitir colocar una tienda donde ya existe otra.
     *
     */
    @Test
    public void accordingJLShouldNotPlaceStoresOnStoreWhenAlreadyExists() {
        road.placeStore(49, 20);
        road.placeStore(49, 1000);
        assertFalse("No debería permitir colocar tienda sobre una tienda", road.ok());
        assertEquals("Solo deberia existir una tienda la primera creada", 1, road.stores().length);
    }
    /**
     * Debería crear un robot válida en una posición libre y dentro de rango.
     *
     */
    @Test
    public void accordingJLShouldPlaceRobotCorrectlyWhenLocationValid(){
        road.placeRobot(34);
        assertTrue("Se debio crear un robot en la posicion 34", road.ok());
        assertEquals("Ahora hay un robot en la lista", 1, road.robots().length);
        }
        
    /**
     * Debería recolectar los tenges si se pone un robot sobre una tienda. 
     *
     */
    @Test
    public void accordingJSShouldCollectProfitWhenRobotOnStore() {
        road.placeStore(10, 20);
        road.placeRobot(10);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("El robot debería recoger los 20 tenges (distancia 0)", 20, road.getProfit());
        }
    
    /**
     * Debería recolectar los tenges si se pone una tienda sobre un robot. 
     *
     */
    @Test
    public void accordingJSShouldCollectProfitWhenStoreOnRobot() {
        road.placeRobot(10); 
        road.placeStore(10, 50);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("El robot debería recoger los 50 tenges (distancia recorrida 0)", 50, road.getProfit());
    }
    
    /**
     * No debería permitir colocar un robot donde ya existe otro.
     *
     */
    @Test
    public void accordingJLShouldNotPlaceRobotsOnStoreWhenAlreadyExists() {
        road.placeRobot(49);
        road.placeRobot(49);
        assertFalse("No debería permitir colocar un robot cuando ya existe uno alli", road.ok());
        assertEquals("Solo deberia existir un robot el primero creado", 1, road.robots().length);
    }
    
    /**
     * No debería permitir colocar un robot feura de los limites del tablero.
     *
     */
    @Test
    public void accordingJSShouldNotPlaceRobotWhenLocationOutOfBounds(){
        road.placeRobot(100);
        assertFalse("La ultima operacion debio dar error (false)", road.ok());
        assertEquals("No debe haberse creado ningun robot", 0, road.robots().length);
    }
    /**
     * Debería recolectar monedas de una tienda en la nueva ubicación y actualizar el profit.
     *
     */
    @Test
    public void accordingJLShouldMoveRobotCorrectlyAndCollectTenges(){
        road.placeRobot(0);
        road.placeStore(1, 10);
        road.moveRobot(0, 1);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("El profit debio ser actualizado a 10-1=9", 9, road.getProfit());
    }
    /**
     * No debería recolectar si la tienda no tiene monedas.
     *
     */
    @Test
    public void accordingJSShouldNotCollectFromEmptyStore(){
        road.placeRobot(0);
        road.placeRobot(1);
        road.placeStore(2, 10);
        road.moveRobot(1, 1);
        road.moveRobot(0, 2);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("El profit debio mantenerse en 9", 9, road.getProfit());
    }
    /**
     * Debería eliminar correctamente una tienda existente.
     *
     */
    @Test
    public void accordingJLRemoveStoreCorrectlyWhenExists(){    
        road.placeStore(2, 10);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("Se deberia haber creado la tienda", 1, road.stores().length);
        road.removeStore(2);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("Se deberia haber eliminado la tienda", 0, road.stores().length);
    }
    /**
     * No debería eliminar una tienda que no existe.
     *
     */
    @Test
    public void accordingJLShouldNotRemoveStoreWhenNotExists(){
        road.removeStore(2);
        assertFalse("La operación debería ser inválida", road.ok());
    }

    /**
     * Debería eliminar correctamente un robot existente.
     *
     */
    @Test
    public void accordingJsShouldRemoveRobotCorrectlyWhenExists(){
        road.placeRobot(2);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("Se deberia haber creado un robot", 1, road.robots().length);
        road.removeRobot(2);
        assertTrue("La operación debería ser válida", road.ok());
        assertEquals("Se deberia haber eliminado el robot", 0, road.robots().length);
    }
    
    /**
     * No debería eliminar un robot que no existe.
     *
     */
    @Test
    public void accordingJLShouldNotRemoveRobotWhenNotExists(){
        road.removeRobot(2);
        assertFalse("La operación debería ser inválida", road.ok());
    }
    
    /**
     * Debería reabastecer todas las tiendas a su cantidad inicial.
     * 
     */
    @Test
    public void accordingJLShouldResupplyStoresCorrectly(){
        road.placeRobot(0);
        road.placeStore(1, 10);
        road.moveRobot(0, 1);
        road.resupplyStores();
        int[][] stores = road.stores();        
        assertEquals("la cantidad de tenges reabastecidos debe ser 10", 10, stores[0][1]);
    
    }
    
    /**
     * Debería reiniciar los robots a su posición inicial.
     *
     */
    @Test
    public void accordingJLShouldReturnRobotsToInitialPosition(){
        road.placeRobot(0);
        road.moveRobot(0, 10);
        road.returnRobots();
        int[][] robots = road.robots();        
        assertEquals("El robot debeio haber vuelto a su posicion 0", 0, robots[0][1]);
    
    }
    /**
     * Debería aumentar el profit correctamente al recolectar tenges de una tienda.
     *
     */
    @Test
    public void accordingJSShouldIncreaseProfitWhenCollectingFromStore(){
        road.placeRobot(0);
        road.placeStore(10, 90);
        road.moveRobot(0, 10);
        assertEquals("El profit debio ser actualizado a 90-10=80", 80, road.getProfit());
    
    }
    
    /**
     * No debería aumentar si no hay recolección posible (tienda vacía).
     *
     */
    @Test
    public void accordingJSShouldNotIncreaseProfitWhenNoCollection(){
        road.placeRobot(0);
        road.placeStore(10, 0);
        road.moveRobot(0, 10);
        assertEquals("El profit se debio mantener en 0", 0, road.getProfit());
    
    }
    
}
