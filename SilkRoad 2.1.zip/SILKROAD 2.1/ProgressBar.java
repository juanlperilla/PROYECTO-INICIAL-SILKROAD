
/**
 * Write a description of class ProgressBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class ProgressBar {
    private Rectangle border;
    private Rectangle fill;
    private int maxWidth ;
    private int high;

    public ProgressBar(int x, int y, int width, int high) {
        this.maxWidth = width;
        this.high = high;

        
        border = new Rectangle();
        border.changeSize(width, high);
        border.moveHorizontal(x);
        border.moveVertical(y);
        border.changeColor("black");

        
        fill = new Rectangle();
        fill.changeSize(0, high);
        fill.moveHorizontal(x);
        fill.moveVertical(y);
        fill.changeColor("green");
    }
    
    public void makeVisible(){
        fill.makeVisible();
        border.makeVisible();
    }
    
    public void makeInvisible(){
        fill.makeInvisible();
        border.makeInvisible();
    }
        
    public void update(int actual, int max) {
        if (actual < 0) actual = 0;
        if (actual > max) actual = max;

        int nuevoAncho = (actual * maxWidth) / max;
        fill.changeSize(nuevoAncho, high);
    }
}