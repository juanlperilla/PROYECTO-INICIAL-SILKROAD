
/**
 * A class that contains Store methods for silkroad.
 * 
 * @author (Juan Camilo Lizarazo) 
 * @version (1.0)
 */
public class Store
{
    
    private int location;
    private int tenges;
    private int initialTenges;
    private String initialColor;
    private String actualColor;
    private Rectangle box;
    private Triangle rooft;
    private int emptiedCount;
    
    public Store(int location, int tenges) {
        this.location = location;
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.initialColor = "";
        this.actualColor = "";
        box = new Rectangle();
        box.changeSize(30, 100);
        box.moveHorizontal(75);
        box.moveVertical(50);
        rooft = new Triangle();
        rooft.changeSize(50, 100);
        rooft.moveHorizontal(125);
        rooft.moveVertical(0);
    }
    
    public void changeColor(String color){
    box.changeColor(color);
    rooft.changeColor(color);
    actualColor = color;
    }
    
    public void graphicMove(int row, int col){
    box.moveHorizontal(75+250*col);
    box.moveVertical(50+250*row);
    rooft.moveHorizontal(125+250*col);
    rooft.moveVertical(250*row);
    }
    
    public void makeVisible() {
        box.makeVisible();
        rooft.makeVisible();
    }
    
    public void makeInvisible() {
        box.makeInvisible();
        rooft.makeInvisible();
    }
    
    public int getLocation() { 
        return location; 
    }
    
    public int getTenges() { 
        return tenges; 
    }
    
    public void reset() {
        changeColor(initialColor);
        this.tenges = initialTenges; 
    }
    
    //Ciclo 1 Debe permitir consultar el número de veces en que cada tienda ha sido desocupada y Las tiendas desocupadas deben lucir diferentes
    public int collect() {
        changeColor("black");
        int amount = tenges;
        tenges = 0;
        emptiedCount++;
        return amount;
    }
    
    public int getEmptiedCount() {
    return emptiedCount;
    }
    
    public String getActualColor(){
        return actualColor;
    }
    
    public void setInitialColor(String color){
        initialColor = color;
    }
}
