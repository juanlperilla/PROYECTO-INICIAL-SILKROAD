
/**
 * Write a description of class MarathonConsole here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.util.*;

public class MarathonConsole {
    public static void start(SilkRoad game) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        sc.nextLine();

        List<String> events = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            events.add(sc.nextLine());
        }

        game.makeVisible();        
        game.loadFromMarathonInput(events);
    }
}


