package test;
import silkroad.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.After;

/**
 * The test class SilkRoadContestTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SilkRoadContestTest{
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }
    
    @Test
    public void accordingJLShouldgetSampleCase  () {
        int[][] days = {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50},
            {1, 50},
            {2, 80, 20},
            {2, 70, 30}
        };
        
        int[] expected = {0, 10, 35, 50, 50, 60};
        int[] result = SilkRoadContest.solve(days);
        
        assertArrayEquals("Debe coincidir con el ejemplo del enunciado", expected, result);
    }
    
    @Test
    public void accordingJLShouldTestSingleRobotSingleStore() {
        int[][] days = {
            {1, 10},
            {2, 15, 10}
        };
        
   
        int[] expected = {0, 5};
        int[] result = SilkRoadContest.solve(days);
        
        assertArrayEquals("Debe calcular correctamente la ganancia simple", expected, result);
    }
    
     @Test
    public void accordingJLShouldTestMultipleRobotsAndStores() {
        int[][] days = {
            {1, 10},
            {1, 50},
            {2, 20, 10},
            {2, 60, 15}
        };

        int[] expected = {0, 0, 0, 5};
        int[] result = SilkRoadContest.solve(days);

        assertArrayEquals("Debe manejar múltiples robots y tiendas", expected, result);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}