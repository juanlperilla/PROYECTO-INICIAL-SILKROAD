package test;
import silkroad.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.After;
import java.util.ArrayList;
import java.util.List;

/**
 * The test class SilkRoadContestC4test.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SilkRoadContestC4test
{
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }
    /**
     * Verifica que la AutoStore eliga una ubicacion unica y aleatoria.
     */
    @Test
    public void accordingJLShouldAssignUniqueRandomLocationWhenCreated() {
        ArrayList<Store> stores = new ArrayList<>();
        Store existing = new Store(3, 50, 10);
        stores.add(existing);

        AutoStore auto = new AutoStore(stores, 20, 10);

        int loc = auto.getLocation();
        assertNotEquals("La ubicación aleatoria no debe coincidir con una tienda existente", 
                        existing.getLocation(), loc);
        assertTrue("La ubicación debe estar dentro del tablero", loc >= 0 && loc < 10);
    }
    /**
     * Verifica que la FightStore solo peuda entregar tenges a robots con mas ganancias que ella.
     */
    @Test
    public void accordingJLShouldAllowCollectionOnlyIfRobotHasMoreTenges() {
        FightStore store = new FightStore(5, 50, 20);
        Robot richRobot = new Robot(0);
        Robot poorRobot = new Robot(0);
    
        richRobot.addGain(0, 100);
        poorRobot.addGain(1, 30);
    

        boolean canRichCollect = store.canBeCollected(richRobot);
        boolean canPoorCollect = store.canBeCollected(poorRobot);
    
        assertTrue("El robot con más tenges debe poder recolectar", canRichCollect);
        assertFalse("El robot con menos tenges no debe poder recolectar", canPoorCollect);
    }
    
    /**
     * Verifica que el robot nunca retrocede: si se intenta mover negativo, se invierte a positivo.
     */
    @Test
    public void testNeverMovesBackwards() {
        Robot robot = new NeverRobot(5);
        int initial = robot.getLocation();
        robot.makeMove(-4, 30);
        assertTrue("El robot nunca debe retroceder", robot.getLocation() > initial);
    }
    /**
     * Verifica que el robot calcula correctamente el mejor movimiento posible.
     */

    @Test
    public void testCalculateBestMove() {
        Robot robot = new NeverRobot(5);
        ArrayList<Store> stores = new ArrayList<>();

        stores.add(new Store(8, 10, 30));
        stores.add(new Store(12, 4, 30));
        stores.add(new Store(15, 20, 30)); 
        stores.add(new Store(2, 10, 30));
        
        int move = robot.calculateBestMove(stores);
        assertEquals("El mejor movimiento debe ser hacia la tienda en posición 8", 3, move);
    }
    
    /**
     * Verifica que el robot Tender recolecta solo la mitad del dinero disponible (menos el precio de movimiento).
     * 
     * Suponemos que el método collect de Robot usa getTenges() directamente,
     * por lo que aquí simulamos el comportamiento esperado para TenderRobot.
     */
    @Test
    public void accordingJLShouldCollectHalfTenges() {
        SilkRoad game = new SilkRoad(9);
        
        game.placeStore(1, 100, "0");
        game.placeRobot(0, "2");

        int expectedGain = (100 / 2) - 1;
        
        game.moveRobot(0, 1);

        assertEquals("Debe recolectar solo la mitad de los tenges", 
                     expectedGain, 
                     game.especificRobotGains(1).get(0).getSecond());
    }
    /**
     * Verifica que el robot Friendly recolecta solo  solo el 10% del dinero disponible (menos el precio de movimiento).
     * 
     * Suponemos que el método collect de Robot usa getTenges() directamente,
     * por lo que aquí simulamos el comportamiento esperado para TenderRobot.
     */
    @Test
    public void accordingJLShouldCollectTenPercentTenges() {
        SilkRoad game = new SilkRoad(9);
        
        game.placeStore(1, 100, "0");
        game.placeRobot(0, "3");

        int expectedGain = Math.round(100 * 0.10f) - 1;
        
        game.moveRobot(0, 1);

        assertEquals("Debe recolectar solo el 10%  de los tenges", 
                     expectedGain, 
                     game.especificRobotGains(1).get(0).getSecond());
    }
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}