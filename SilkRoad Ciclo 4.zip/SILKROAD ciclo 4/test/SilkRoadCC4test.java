package test;
import silkroad.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.After;
/**
 * The test class SilkRoadCC4test.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SilkRoadCC4test{
    private SilkRoad road;
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp(){
        road = new SilkRoad(10);
    }
    /**
     * 
     *Prueba que se creen diferentes tipos de robots Correctamente
     * 
     */
    @Test
    public void accordingJLShouldCreateDifferentTypesOfRobots() {
        road.placeRobot(3, "0");
        road.placeRobot(0, "1");
        road.placeRobot(1, "2");
        road.placeRobot(2, "3");
        assertTrue("Debe crear varios tipos de robot correctamente", road.ok());
        assertEquals("Debe haber 3 robots creados", 4, road.robots().length);
    }
    /**
     * 
     *Prueba que se creen diferentes tipos de robots Correctamente
     * 
     */
    @Test
    public void accordingJLShouldCreateDifferentTypesOfStores() {
        road.placeStore(0, 10, "0");
        road.placeStore(1, 20, "1");
        road.placeStore(1, 20, "1");
        assertTrue("Debe crear varios tipos de robot correctamente", road.ok());
        assertEquals("Debe haber 3 robots creados", 3, road.stores().length);
    }
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}