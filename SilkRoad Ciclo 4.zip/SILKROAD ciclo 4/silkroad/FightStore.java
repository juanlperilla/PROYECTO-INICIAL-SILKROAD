package silkroad;
import shapes.Rectangle;

/**
 * Representa una tienda Fighter (Solo los robots con mas tenge que ella puede recolectar) dentro del simulador Silk Road.
 * 
 * Cada tienda tiene una ubicación, una cantidad de tenges (moneda del juego),
 * una representación gráfica compuesta por un rectángulo (cuerpo) y un triángulo (techo),
 * y puede ser recolectada, reiniciada, movida gráficamente y cambiar de color.
 * 
 * @author (Juan Lizarazo) 
 * @version (1.0)
 */
public class FightStore extends Store{
    private Rectangle detail;

    /**
     * Crea una FightStore en una ubicación específica con una cantidad inicial de tenges.
     * 
     * @param location Posición de la tienda en la ruta.
     * @param tenges Cantidad inicial de tenges disponibles en la tienda.
     * @param size tamaño total del tablero.
     */
    public FightStore(int location, int tenges, int size){
        super(location, tenges, size);  
    }
    
    @Override
    /**
     * Determina si la tienda actual puede ser recolectada por el robot especificado.
     *
     * @param collector el robot que intenta recolectar el objeto
     * @return {@code true} si {@code collector.getTotalGains()} es mayor que {@code getTenges()},
     *         {@code false} en caso contrario
     */
    public boolean canBeCollected(Robot collector){
        if (collector.getTotalGains() > getTenges()){
        return true;
        }
        return false;
    }
    
    /**
     * Mueve gráficamente la tienda a una posición en la cuadrícula.
     * 
     * @param row Fila en la cuadrícula.
     * @param col Columna en la cuadrícula.
     */
    @Override
    public void graphicMove(int row, int col){
    if (detail == null) {
        this.detail = new Rectangle();
        detail.changeColor("black");
        detail.changeSize(30, 30);
        detail.moveHorizontal(110);
        detail.moveVertical(35);
    }
    super.graphicMove(row, col);
    detail.moveHorizontal(110+250*col);
    detail.moveVertical(35+250*row);
    }
    
    /**
     * Hace visible la tienda en el lienzo.
     */
    @Override
    public void makeVisible() {
    super.makeVisible();
    detail.makeVisible();
    }
    
    /**
     * Oculta la tienda del lienzo.
     */

    @Override
    public void makeInvisible() {
    super.makeInvisible();
    detail.makeInvisible();
    }
    
    /**
     * Cambia el color gráfico de la tienda.
     * 
     * @param color Nuevo color a aplicar.
     */
    @Override
    public void changeColor(String color){
    super.changeColor(color);
    detail.changeColor("black");
    }
}