package silkroad;
import shapes.*;
import java.util.*;


/**
 * A class that contains Robot methods for silkroad.
 * 
 * @author (Juan Camilo Lizarazo) 
 * @version (1.0)
 * Representa un robot dentro del juego SilkRoad.  
 *
 * Cada robot tiene una posición inicial y actual, un registro de ganancias obtenidas
 * y una representación gráfica compuesta por varias figuras geométricas (cabeza, cuerpo, brazos y piernas).
 * </p>
 *
 * 
 * El robot puede moverse, calcular su mejor movimiento en función de las tiendas disponibles,
 * y actualizar su color o visibilidad en el entorno gráfico.
 * 
 */
public class Robot implements Unit{
    private int initialLocation;
    private int[] initialCords;
    private int currentLocation;
    private String initialColor;
    private List<Tupla> gains;
    private int totalgains;
    private Circle head;
    private Rectangle neck;
    private Rectangle body;
    private Rectangle lefthand;
    private Rectangle righthand;
    private Rectangle leftleg;
    private Rectangle rightleg;
    private ArrayList<Figura> parts;
    /**
     * Crea un nuevo robot en la ubicación especificada.
     *
     * @param location posición inicial del robot en la carretera de la seda.
     */
    public Robot(int location) {
        this.initialLocation = location;
        this.currentLocation = location;
        this.gains = new ArrayList<>();
        this.totalgains = 0;
        this.head = new Circle();
        head.changeSize(50);
        head.moveHorizontal(98);
        head.moveVertical(90);
        this.neck = new Rectangle();
        neck.changeSize(15,10);
        neck.moveHorizontal(118);
        neck.moveVertical(140);
        this.body = new Rectangle();
        body.changeSize(50, 60);
        body.moveHorizontal(95);
        body.moveVertical(147);
        this.lefthand = new Rectangle();
        lefthand.changeSize(50, 10);
        lefthand.moveHorizontal(85);
        lefthand.moveVertical(155);
        this.righthand = new Rectangle();
        righthand.changeSize(50, 10);
        righthand.moveHorizontal(155);
        righthand.moveVertical(155);
        this.leftleg = new Rectangle();
        leftleg.changeSize(50, 10);
        leftleg.moveHorizontal(130);
        leftleg .moveVertical(180);
        this.rightleg = new Rectangle();
        rightleg.changeSize(50, 10);
        rightleg.moveHorizontal(110);
        rightleg .moveVertical(180);
        this.parts = new ArrayList<>();
        parts.add(this.head);
        parts.add(this.neck);
        parts.add(this.body);
        parts.add(this.righthand);
        parts.add(this.lefthand);
        parts.add(this.rightleg);
        parts.add(this.leftleg);
    }

    /**
     * Cambia el color de todas las partes del robot.
     *
     * @param color el nuevo color en formato de texto (por ejemplo, "red", "blue").
     */
    public void changeColor(String color){
    for (Figura f: parts){
        f.changeColor(color);
    }
    }
    
    /**
     * Setea el el color inicial de todas las partes del robot.
     *
     * @param color el nuevo color en formato de texto (por ejemplo, "red", "blue").
     */
    public void setInitialColor(String color){
         this.initialColor = color;
         this.changeColor(color);
    }
    
    /**
     * devuelve el el color inicial de todas las partes del robot.
     *
     * @param color el nuevo color en formato de texto (por ejemplo, "red", "blue").
     */
    public String getInitialColor(){
        return initialColor;
    }
    
    /**
     * Mueve gráficamente al robot hacia la celda especificada por fila y columna.
     * 
     * Las coordenadas se transforman en posiciones absolutas dentro del entorno gráfico.
     * 
     *
     * @param row la fila a la que se desea mover el robot.
     * @param col la columna a la que se desea mover el robot.
     */
    public void graphicMove(int row, int col){
    head.moveHorizontal(98+250*col);
    head.moveVertical(90+250*row);
    neck.moveHorizontal(118+250*col);
    neck.moveVertical(140+250*row);
    body.moveHorizontal(95+250*col);
    body.moveVertical(147+250*row);
    lefthand.moveHorizontal(85+250*col);
    lefthand.moveVertical(155+250*row);
    righthand.moveHorizontal(155+250*col);
    righthand.moveVertical(155+250*row);
    leftleg.moveHorizontal(130+250*col);
    leftleg.moveVertical(180+250*row);
    rightleg.moveHorizontal(110+250*col);
    rightleg.moveVertical(180+250*row);
    }
    
    /**
     * Hace visible al robot y todas sus partes gráficas.
     */
    public void makeVisible() {
    for (Figura f: parts){
        f.makeVisible();
    }
    }
    /**
     * Oculta al robot y todas sus partes gráficas.
     */
    public void makeInvisible() {
    for (Figura f: parts){
        f.makeInvisible();
    }
    }
    /**
     * Obtiene la ubicación actual del robot.
     *
     * @return la posición actual del robot.
     */
    public int getLocation() { 
        return currentLocation; 
    }
    /**
     * Obtiene la ubicación actual del robot.
     *
     * @param lenght tamaño del tablero.
     */
    public void setInitialCords(int lenght) { 
         initialCords = positionToCoords(initialLocation, lenght); 
    }
    /**
     * Obtiene la ubicación inicial del robot (al crearse).
     *
     * @return la posición inicial del robot.
     */
    public int getInitialLocation() { 
        return initialLocation; 
    }
    /**
     * Reinicia la posición actual del robot a su ubicación inicial (logicamente).
     */
    public void reset() {
        currentLocation = initialLocation;
    }
    /**
     * Reinicia la posición actual del robot a su ubicación inicial (logicamente y graficamente).
     */
    public void graphicReset() {
        graphicMove(initialCords[0], initialCords[1]);
        reset();
    }
    
    /**
     * Mueve al robot una cantidad específica de metros (logicametne).
     *
     * @param meters cantidad de unidades que debe moverse (puede ser negativa).
     */
    public void move(int meters) {
        currentLocation += meters;
    }
    
     /**
     * Registra una ganancia obtenida por el robot en una ubicación específica.
     *
     * @param locationwhereitwasgain ubicación donde se obtuvo la ganancia.
     * @param gain cantidad de tenges ganados.
     */
    public void addGain(int locationwhereitwasgain, int gain) {
    Tupla locyg = new Tupla(locationwhereitwasgain, gain);
    gains.add(locyg);
    this.totalgains += gain;
    }
    /**
     * Devuelve el total acumulado de ganancias obtenidas por el robot.
     *
     * @return el total de ganancias.
     */
    public int getTotalGains() {
    return totalgains;
    }
    /**
     * Devuelve la lista de ganancias individuales del robot.
     *
     * @return una lista de objetos {@code Tupla} con ubicación y ganancia.
     */
    public List<Tupla> getGains() {
    return gains;
    }
    /**
     * Calcula el mejor movimiento posible del robot basándose en las tiendas disponibles.
     * 
     * Evalúa todas las posibles rutas y determina aquella que maximiza la ganancia total,
     * considerando la distancia y los tenges disponibles en cada tienda.
     * 
     *
     * @param stores lista de tiendas disponibles con su ubicación y tenges.
     * @return el desplazamiento (en metros) que debe realizar el robot para obtener el máximo beneficio,
     *         o {@code 0} si no hay un movimiento rentable.
     */
    public int calculateBestMove(List<Store> stores) {
    int pos = this.getLocation();
    int bestMove = 0;
    int bestTotalProfit = Integer.MIN_VALUE;
    int bestDistance = Integer.MAX_VALUE;

    for (Store s : stores) {
        int sLoc = s.getLocation();
        int sTenges = s.getTenges();
        if (sTenges <= 0 || sLoc == pos || !s.canBeCollected(this)) continue;

        int distToS = Math.abs(sLoc - pos);
        int immediate = sTenges - distToS;

        if (immediate < 0) continue;

        
        Map<Integer, Integer> tempStock = new HashMap<>();
        for (Store t : stores) tempStock.put(t.getLocation(), t.getTenges());

        int totalProfit = immediate;
        tempStock.put(sLoc, 0);
        int curPos = sLoc;

        while (true) {
            int bestContGain = Integer.MIN_VALUE;
            int bestContLoc = -1;

            for (Map.Entry<Integer, Integer> e : tempStock.entrySet()) {
                int loc = e.getKey();
                int stock = e.getValue();
                if (stock <= 0) continue;
                int d = Math.abs(loc - curPos);
                int gain = stock - d;
                if (gain > bestContGain) {
                    bestContGain = gain;
                    bestContLoc = loc;
                }
            }

            if (bestContGain > 0) {
                totalProfit += bestContGain;
                tempStock.put(bestContLoc, 0);
                curPos = bestContLoc;
            } else {
                break;
            }
        }

        if (totalProfit > bestTotalProfit ||
            (totalProfit == bestTotalProfit && distToS < bestDistance)) {
            bestTotalProfit = totalProfit;
            bestMove = sLoc - pos;
            bestDistance = distToS;
        }
    }

    return (bestTotalProfit > 0) ? bestMove : 0;
    }
    
    

    /**
     * Calcula la distancia a la tienda más cercana que tenga al menos un tenge disponible.
     *
     * <p>Este método recorre la lista de tiendas proporcionada y calcula la distancia absoluta
     * entre la ubicación actual del robot y la ubicación de cada tienda que tenga {@code tenges > 0}.
     * Retorna la menor de estas distancias. Si ninguna tienda cumple con la condición,
     * retorna {@code 0}.</p>
     *
     * @param stores una lista de objetos {@code Store} que representan las tiendas disponibles
     * @return la distancia mínima a una tienda con tenges disponibles, o {@code 0} si no hay ninguna
     */
    public int distanceToNearestStore(List<Store> stores) {
    int minDist = Integer.MAX_VALUE;
    for (Store s : stores) {
        if (s.getTenges() > 0) {
            int dist = Math.abs(this.currentLocation - s.getLocation());
            if (dist < minDist) minDist = dist;
        }   
    }
    return (minDist == Integer.MAX_VALUE) ? 0 : minDist;
    }  
    
    /**
     * Convierte una localizacion lineal a cordenadas de una matriz recorriendo en forma de espiral cuadrada.
     * @param location localización que se quiere encontrar en la espiral.
     * @param length tamaño total de la espiral.
     * @return int[]{x, y} devuelve las cordenadas en cordenadas de matriz.
     * @return null devuelve si no se pudo encontrar la ubicacion.
     */
    public int[] positionToCoords(int location, int length) {
        int n = (int) Math.ceil(Math.sqrt(length));
        int[][] board = new int[n][n];
        
        
        int[] dx = {0, 1, 0, -1};
        int[] dy = {1, 0, -1, 0};
        int dir = 0;
        
        int x = 0, y = 0;
        boolean[][] visited = new boolean[n][n];
        
        for (int k = 0; k < length; k++) {
            board[x][y] = k;
            if (k == location) {
                return new int[]{x, y};
            }
            visited[x][y] = true;
            
            int nx = x + dx[dir], ny = y + dy[dir];
            if (nx < 0 || nx >= n || ny < 0 || ny >= n || visited[nx][ny]) {
                dir = (dir + 1) % 4;
                nx = x + dx[dir];
                ny = y + dy[dir];
            }
            x = nx; y = ny;
        }
        return null;
    }
    
    /**
     * Realiza un movimiento instantáneo del robot si se encuentra en la ubicación especificada.
     *
     * <p>Este método calcula la nueva posición del robot sumando los metros al valor de {@code location}.
     * Luego convierte esa posición a coordenadas gráficas y actualiza la visualización mediante {@code graphicMove}.
     * Finalmente, actualiza la posición lógica del robot con {@code move(meters)}.</p>
     *
     * @param location la ubicación actual esperada del robot
     * @param meters la cantidad de unidades que debe moverse el robot
     * @param length la longitud de la cuadrícula o mapa para convertir posiciones a coordenadas
     */
    public void makeMove(int meters, int length){
    int finallocation = this.currentLocation + meters;
    int[] cords = positionToCoords(finallocation, length);
    graphicMove(cords[0], cords[1]);
    move(meters);
    }
    
    /**
     * Realiza un movimiento animado paso a paso del robot si se encuentra en la ubicación especificada.
     *
     * <p>Este método simula el movimiento del robot de forma gradual, actualizando su posición gráfica
     * en cada paso desde {@code location} hasta {@code location + meters}. La dirección del movimiento
     * se determina por el signo de {@code meters}. Al finalizar, se actualiza la posición lógica del robot
     * con {@code move(meters)}.</p>
     *
     * @param location la ubicación actual esperada del robot
     * @param meters la cantidad de unidades que debe moverse el robot (puede ser negativa)
     * @param length la longitud de la cuadrícula o mapa para convertir posiciones a coordenadas
     */
    public void makeMoveSlow(int meters, int length){
            int finalLocation = this.currentLocation + meters;
            int step = (meters > 0) ? 1 : -1;
            int currentStep = this.currentLocation;
            while (currentStep != finalLocation) {
            currentStep += step;
            int[] cords = positionToCoords(currentStep, length);
            graphicMove(cords[0], cords[1]);
            }
            move(meters);
    
    }
    /**
     * Devuelve que tipo de robots es 
     *
     *@return String "Normal" Robot Normal.
     */
    public String type(){
        return "Normal";
    }
}