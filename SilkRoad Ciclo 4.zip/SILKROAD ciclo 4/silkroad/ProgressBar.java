package silkroad;
import java.util.List;
import java.util.ArrayList;
import shapes.*;

/**
 * Representa una barra de progreso gráfica que puede actualizarse dinámicamente.
 * 
 * La barra está compuesta por un borde negro y un relleno verde que crece proporcionalmente
 * al progreso actual. Se puede hacer visible/invisible y ajustar su posición horizontal.
 * 
 * @author Juan Camilo Lizarazo
 * @version 1.0
 */
public class ProgressBar implements Unit{
    private int x;
    private int y;
    private Rectangle border;
    private Rectangle fill;
    private int maxWidth ;
    private int high;
    private ArrayList<Figura> body;

    /**
     * Crea una barra de progreso en una posición específica con dimensiones dadas.
     * 
     * @param x Posición horizontal de la barra.
     * @param y Posición vertical de la barra.
     * @param width Ancho máximo de la barra.
     * @param high Altura de la barra.
     */
    public ProgressBar(int x, int y, int width, int high) {
        this.x = x;
        this.y = y;
        this.maxWidth = width;
        this.high = high;
        this.body = new ArrayList<Figura>();
        border = new Rectangle();
        border.changeSize(width, high);
        border.changeColor("black");
        fill = new Rectangle();
        fill.changeSize(0, high);
        fill.changeColor("green");
        body.add(border);
        body.add(fill);
        for (Figura f: body){
             f.moveHorizontal(x); 
             f.moveVertical(y);
        }
        
        
    }
    
    /**
     * Ajusta la posición horizontal de la barra de progreso.
     * 
     * @param x Nueva posición horizontal.
     */

    public void adjustBoard(int x){
        border.moveHorizontal(x);
        fill.moveHorizontal(x);
    }
    
    /**
     * Hace visible la barra de progreso.
     */

    @Override
    public void makeVisible(){
        fill.makeVisible();
        border.makeVisible();
    }
    
    /**
     * Oculta la barra de progreso.
     */
    @Override
    public void makeInvisible(){
        fill.makeInvisible();
        border.makeInvisible();
    }
    
    
    /**
     * Actualiza el estado de la barra de progreso según el valor actual y el máximo.
     * 
     * @param actual Valor actual del progreso.
     * @param max Valor máximo del progreso.
     */

    public void update(int actual, int max) {
    if (actual < 0) {
        actual = 0;
    }
    if (max < 0) {
        max = 0;
    }
    if (actual > max) {
        actual = max;
    }
    if (max == 0 || actual == 0) {
        fill.makeInvisible();
        return;
    } else {
        fill.makeVisible();
    }

    int nuevoAncho = (actual * maxWidth) / max;

    fill.changeSize(nuevoAncho, high);
    }
}