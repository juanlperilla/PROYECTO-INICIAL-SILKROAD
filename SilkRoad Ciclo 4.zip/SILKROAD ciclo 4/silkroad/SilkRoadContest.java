package silkroad;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;



public class SilkRoadContest{
    
    /**
     * Resuelve la simulación de ganancias día a día en el juego SilkRoad.
     * 
     * Por cada día:
     * - Si el tipo es 1, se agrega un robot en una posición.
     * - Si el tipo es 2, se agrega una tienda con ubicación y ganancia.
     * - Luego, los robots se mueven hacia las tiendas buscando maximizar ganancias.
     * - Se repite mientras algún robot pueda seguir ganando.
     * 
     * @param days Arreglo de días, donde cada día contiene una acción (robot o tienda).
     * @return Arreglo con la ganancia acumulada al final de cada día.
     */
    public static int[] solve(int[][] days) {
    List<Robot> allRobots = new ArrayList<>();     
    List<Store> allStores = new ArrayList<>(); 
    int n = days.length;
    int[] result = new int[n];

    for (int day = 0; day < n; day++) {
        int[] evt = days[day];
        int type = evt[0];

        for (Store s : allStores) s.reset(); 
        for (Robot r : allRobots) r.reset(); 

        if (type == 1) {
            int loc = evt[1];
            Robot newRobot = new Robot(loc);
            allRobots.add(newRobot);
        } else if (type == 2) {
            int loc = evt[1];
            int tenges = evt[2];
            Store newStore = new Store(loc, tenges);
            allStores.add(newStore);
        }


        int dailyProfit = 0;

        int activeStores = 0;
        for (Store s : allStores) if (s.getTenges() > 0) activeStores++;

        for (int round = 0; round < activeStores; round++) {
            boolean anyMovedThisRound = false;

            for (Robot r : allRobots) {
                int meters = r.calculateBestMove(allStores);
                if (meters != 0) {
                    int from = r.getLocation();
                    int to = from + meters;


                    r.move(meters);

                    for (Store s : allStores) {
                        if (s.getLocation() == to && s.getTenges() > 0) {
                            int collected = s.collect("Normal"); 
                            int gain = collected - Math.abs(to - from);
                            if (gain > 0) {
                                r.addGain(to, gain);
                                dailyProfit += gain;
                            }
                            break;
                        }
                    }

                    anyMovedThisRound = true;
                }
            }

            if (!anyMovedThisRound) break;
        }

        result[day] = dailyProfit;

    }

    return result;
    }


    /**
     * Simula visualmente el juego SilkRoad día a día.
     * 
     * Por cada día:
     * - Coloca robots o tiendas según el tipo de evento.
     * - Ejecuta el movimiento de los robots.
     * - Muestra la ganancia acumulada.
     * - Reinicia el estado visual para el siguiente día.
     * 
     * @param days Arreglo de días con eventos.
     * @param slow Si es true, se activa el movimiento lento visual.
     */
    public static void simulate(int[][] days, boolean slow) {

    SilkRoad game = new SilkRoad(days);
    game.makeVisible();
    int[] results = solve(days);
    
    for (int i = 0; i < days.length; i++) {
        int[] day = days[i];
        int type = day[0];

        if (type == 1) {
            game.placeRobot(day[1], "0");
        } else if (type == 2) {
            game.placeStore(day[1], day[2], "0");
        }
        if (slow){ 
        game.moveRobotsSlow();
        }
        game.moveRobots();
        System.out.println(results[i]);
        game.reboot();
    }
    return;
    }
    
    
}   
