package silkroad;
import shapes.*;
import java.util.ArrayList;
import java.util.List;

/**
 * La clase Cell representa una celda gráfica que puede cambiar de color y tamaño.
 * 
 * Cada celda está compuesta por un borde negro y una caja interna de color.
 * Se puede hacer visible/invisible, cambiar su color y ajustar su tamaño.
 * 
 * @author Juan Camilo Lizarazo
 * @version 1.0
 */

public class Cell extends Figura implements Unit{ 
    private Rectangle box;
    private Rectangle border;
    
    public static final int SIZE = 250;
    public static final int MARGIN = Math.round(SIZE*0.016f);
    
    /**
     * Crea una celda gráfica con color, posición X e Y.
     * 
     * @param color Color inicial de la celda.
     * @param x Posición horizontal.
     * @param y Posición vertical.
     */

    public Cell(String color, int x, int y) {
        super.color = color;
        super.xPosition = x;
        super.yPosition =y;
        
        border = new Rectangle();
        border.changeSize(SIZE, SIZE);
        border.changeColor("black");
        border.moveHorizontal(x);
        border.moveVertical(y);
        
        box = new Rectangle();
        box.changeSize(SIZE - MARGIN, SIZE - MARGIN);
        box.changeColor(color);
        box.moveHorizontal(x+MARGIN/2);
        box.moveVertical(y+MARGIN/2);
    }
    
    /**
     * Cambia el tamaño de la celda, ajustando el margen y la posición interna.
     * 
     * @param newSize Nuevo tamaño total de la celda.
     */

    public void changeSize(int newSize){
        int MARGIN = Math.round(newSize*0.016f);
        border.changeSize(newSize, newSize);
        box.changeSize(newSize - MARGIN, newSize - MARGIN);
        box.moveHorizontal(xPosition+MARGIN/2);
        box.moveVertical(yPosition+MARGIN/2);
    }
    
    
    /**
     * Hace visible la celda del canva.
     */
    
    @Override
    public void makeVisible() {
        border.makeVisible();
        box.makeVisible();
    }

   /**
     * Oculta la celda del canva.
    */
    @Override
    public void makeInvisible() {
        border.makeInvisible();
        box.makeInvisible();
    }

    
    /**
     * Obtiene el color actual de la celda.
     * 
     * @return Color de la celda.
     */

    public String getColor() {
        return color;
    }
    
    /**
     * Obtiene el tamaño base de la celda.
     * 
     * @return Tamaño fijo de la celda.
     */

    public int getSize() {
        return SIZE;
    }
    
    /**
     * Cambia el color de la celda.
     * 
     * @param newColor Nuevo color a aplicar.
     */

    public void setColor(String newColor) {
    this.color = newColor;
    box.changeColor(newColor); 
    box.makeVisible();
    }
    
    /**
     * Método de dibujo heredado (no implementado).
     */

    @Override
    public void draw(){
        box.draw();
        border.draw();
    }
    
}