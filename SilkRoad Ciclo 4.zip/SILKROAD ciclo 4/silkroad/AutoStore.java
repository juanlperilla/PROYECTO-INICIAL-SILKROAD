package silkroad;
import shapes.Circle;
import java.util.Random;
import java.util.List;


/**
 * Representa una tienda Autonoma (Elige su posicicon al azar) dentro del simulador Silk Road.
 * 
 * Cada tienda tiene una ubicación, una cantidad de tenges (moneda del juego),
 * una representación gráfica compuesta por un rectángulo (cuerpo) y un triángulo (techo),
 * y puede ser recolectada, reiniciada, movida gráficamente y cambiar de color.
 * 
 * @author (Juan Lizarazo) 
 * @version (1.0)
 */
public class AutoStore extends Store{
    private Circle detail;
     /**
     * Crea una AutoStore en una ubicación aleatoria con una cantidad inicial de tenges.
     * 
     * @param stores lista de tiendas para calcular una ubicacion nueva no ocupada inicial.
     * @param tenges Cantidad inicial de tenges disponibles en la tienda.
     * @param size tamaño total del tablero.
     */
    public AutoStore(List<Store> stores, int tenges, int size){
        super(randLoc(stores, size), tenges, size);  
    }
    
    
    /**
     * Genera una posición aleatoria en el tablero que no esté ocupada por ninguna tienda.
     *
     * @param stores lista de tiendas ya colocadas en el tablero
     * @param size tamaño del tablero (número total de posiciones posibles)
     * @return una posición libre aleatoria
     */
    public static int randLoc(List<Store> stores, int size) {
    Random rand = new Random();
    int location;
    boolean occupied;

    do {
        location = rand.nextInt(size);
        occupied = false;

        for (Store s : stores) {
            if (s.getLocation() == location) {
                occupied = true;
                break;
            }
        }
    } while (occupied);

    return location;
    
    }
    
    /**
     * Mueve gráficamente la tienda a una posición en la cuadrícula.
     * 
     * @param row Fila en la cuadrícula.
     * @param col Columna en la cuadrícula.
     */
    @Override
    public void graphicMove(int row, int col){
        if (detail == null) {
            this.detail = new Circle();
            detail.changeColor("black");
            detail.changeSize(30);
            detail.moveHorizontal(110);
            detail.moveVertical(40);
        }
        super.graphicMove(row, col);
        detail.moveHorizontal(110+250*col);
        detail.moveVertical(40+250*row);
    }
    
    /**
     * Hace visible la tienda en el lienzo.
     */
    @Override
    public void makeVisible() {
    super.makeVisible();
    detail.makeVisible();
    }
    
    /**
     * Oculta la tienda del lienzo.
     */

    @Override
    public void makeInvisible() {
    super.makeInvisible();
    detail.makeInvisible();
    }
    
    /**
     * Cambia el color gráfico de la tienda.
     * 
     * @param color Nuevo color a aplicar.
     */
    @Override
    public void changeColor(String color){
    super.changeColor(color);
    detail.changeColor("black");
    }
}
