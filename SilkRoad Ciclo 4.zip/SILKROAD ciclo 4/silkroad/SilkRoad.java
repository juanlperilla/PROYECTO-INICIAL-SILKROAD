package silkroad;
import java.util.*;
import java.util.Random;
import java.util.Collections;
import java.util.Queue;
import shapes.*;
/**
 * La clase {@code SilkRoad} representa una simulación del juego Silk Road,
 * en el cual se gestionan tiendas, robots y productos dentro de una cuadrícula.
 * Permite visualizar gráficamente los elementos, mover robots y controlar
 * la simulación día a día.
 * 
 * <p>Incluye funcionalidades para mostrar la interfaz, mover entidades,
 * y aplicar acciones según los eventos leídos desde una matriz.</p>
 * 

 * @author (Juan Camilo Lizarazo- Juan Angel Salas) 
 * @version (1.0)
 */
public class SilkRoad implements Unit{
    private int length;
    private List<Store> stores;
    private List<Robot> robots;
    private int profit;
    private boolean lastOperationOk;
    private Board board;
    private boolean showing;
    private ProgressBar bar;
    private int maximumTenge;
    private List<String> availableColors;
    private Queue<Robot> robotMovements;
    
    
    /**
     * Crea una ruta y un tablero de loingitud lenght
     *
     * @param lenght tamaño de la ruta 
     */
    public SilkRoad(int length) {
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.robotMovements = new ArrayDeque<>();
        this.profit = 0;
        this.lastOperationOk = true;
        this.showing = false;
        this.maximumTenge = 0;
        this.availableColors = new ArrayList<>();
        Collections.addAll(availableColors,
                "red", "blue", "yellow", "green", "magenta",
                "orange", "pink", "cyan", "gray", "light_gray", "dark_gray",   
                "brown", "gold", "lime", "teal", "navy", "salmon",               
                "orchid", "coral", "aquamarine", "turquoise", "alice_blue",      
                "crimson", "deep_pink", "chartreuse"                              
        );
        double n = Math.sqrt(length);
        int z = (int) Math.ceil(n);
        board = new Board(z);
        bar = new ProgressBar(0, 0, 250, 100);
        bar.adjustBoard((z*250)+30); 
    }
    /**
     * Crea una nueva instancia del juego {@code SilkRoad}.
     * 
     * @param days la matriz de entrada que define los eventos del juego, donde cada fila
     *               representa un día y los valores determinan las acciones a realizar.
     */
    public SilkRoad(int[][] days) {
        this.length = max2D(days)+1;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.robotMovements = new ArrayDeque<>();
        this.profit = 0;
        this.lastOperationOk = true;
        this.showing = false;
        this.maximumTenge = 0;
        this.availableColors = new ArrayList<>();
        Collections.addAll(availableColors,
                "red", "blue", "yellow", "green", "magenta",
                "orange", "pink", "cyan", "gray", "light_gray", "dark_gray",   
                "brown", "gold", "lime", "teal", "navy", "salmon",               
                "orchid", "coral", "aquamarine", "turquoise", "alice_blue",      
                "crimson", "deep_pink", "chartreuse"                              
        );
        double n = Math.sqrt(length);
        int z = (int) Math.ceil(n);
        board = new Board(z);
        bar = new ProgressBar(0, 0, 250, 100);
        bar.adjustBoard((z*250)+30);
        int zoomOuts = Math.max(0, (int) Math.ceil((z - 3) * 0.8));
        for (int i = 0; i < zoomOuts+1; i++) {
        zoomOut();
        }
    }
    
     /**
     * Muestra todos los elementos del juego en pantalla, incluyendo
     * el terreno, la cuadrícula, robots y tiendas.
     */
    @Override
    public void makeVisible(){
        board.makeVisible();
        bar.makeVisible();
        for (Store s : stores) {
            s.makeVisible();
        }
        for (Robot r : robots) {
            r.makeVisible();
        }
        showing = true;
    }
    
    /**
     * Oculta la ruta 
     */
    @Override
    public void makeInvisible(){
        board.makeInvisible();
        bar.makeInvisible();
        for (Store s : stores) {
            s.makeInvisible();
            }
        for (Robot r : robots) {
            r.makeInvisible(); 
        }
        showing = false;
    }
    /**
     * Intenta colocar una tienda en la ubicación dada.
     * Si ya existe una tienda en esa posición o la localización es inválida,
     * la operación falla y no se crea la tienda. Y si se esta mostrando se actualiza el grafico.
     *
     * @param location índice de la localización donde se intentará crear la tienda.
     * @param tenges cantidad inicial de monedas que contendrá la tienda.
     * @param type cantidad inicial de monedas que contendrá la tienda.
     */
    public void placeStore(int location, int tenges, String type) {
        Store newstore;
        if (location >= length|| location < 0) {
            lastOperationOk = false;
            return;
        }
        for (Store s : stores) {
            if (s.getLocation() == location) {
                lastOperationOk = false;
                return;
            }
        }
        switch (type){
        case "0":
            newstore = new Store(location, tenges, this.length);
            break;
        case "1":
            newstore = new AutoStore(stores, tenges, this.length);
            break;
        case "2":
            newstore = new FightStore(location, tenges, this.length);
            break;
        case "3":
            newstore = new AutoTengeStore(location, tenges, this.length);
            break;
        default:
            newstore = new Store(location, tenges, this.length);
            break;
        }
        newstore.changeColor(randomColor());
        newstore.setInitialColor(newstore.getActualColor());
        stores.add(newstore);
        stores.sort(Comparator.comparingInt(Store::getLocation));
        maximumTenge += tenges;
        for (Robot r : robots) {
                    if ((r.getLocation() == newstore.getLocation()) && (newstore.getTenges() > 0) && (newstore.canBeCollected(r))) {
                        int collected = newstore.collect(r.type());
                        int distance = Math.abs(r.getInitialLocation() - newstore.getLocation());
                        int gain = collected - distance;
                        profit += gain;
                        r.addGain(location, Math.max(gain, 0));
            }
        }
        if (showing) {
            newstore.makeVisible();
            bar.update(profit, maximumTenge);
        }
        lastOperationOk = true;
    }
    /**
     * Busca y elimina una tienda.
     *
     * @param location localización de la tienda.
     */
    public void removeStore(int location) {
        boolean removed = stores.removeIf(s -> { if (s.getLocation() == location){
                s.makeInvisible();
                s.reset();
                maximumTenge -= s.getInitialTenges();
                return true;
        }
        return false;
        });
        if (showing){
            bar.update(profit, maximumTenge);
        }
        lastOperationOk = removed;
    }
    /**
     * Reinicia las monedas en todas las tiendas.
     *
     */
    public void resupplyStores() {
        for (Store s : stores) {
            s.reset();
        }
        lastOperationOk = true;
    }

    /**
     * Intenta colocar un Robot en la ubicación dada.
     * Si ya existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se crea el Robot. Y si se esta mostrando se actualiza el grafico.
     *
     * @param location índice de la localización donde se intentará crear el Robot.
     */
    public void placeRobot(int location, String type) {
        Robot newrobot;
        if (location >= this.length || location < 0) {
            lastOperationOk = false;
            return;
        }
        for (Robot r : robots) {
            if (r.getLocation() == location) {
                lastOperationOk = false;
                return;
                
            }
        }
        switch (type){
        case "0":
            newrobot = new Robot(location);
            break;
        case "1":
            newrobot = new NeverRobot(location);
            break;
        case "2":
            newrobot = new TenderRobot(location);
            break;
        case "3":
            newrobot = new FriendlyRobot(location);
            break;
        default:
            newrobot = new Robot(location);
            break;
        }
        newrobot.makeMove(0, length);
        newrobot.setInitialCords(length);
        newrobot.setInitialColor(randomColor());
        robots.add(newrobot);
        robotMovements.offer(newrobot);
        robots.sort(Comparator.comparingInt(Robot::getLocation));
        for (Store s : stores) {
                    if (s.getLocation() == location && s.getTenges() > 0 && s.canBeCollected(newrobot)) {
                        int collected = s.collect(newrobot.type());
                        int distance = Math.abs(newrobot.getInitialLocation() - s.getLocation());
                        int gain = collected - distance;
                        newrobot.addGain(location, Math.max(gain, 0));
                        profit += gain;
            }
        }
        if (showing) {
            newrobot.makeVisible();
            bar.update(profit, maximumTenge);
        }
        lastOperationOk = true;
    }
    /**
     * Busca un Robot en la ubicación dada y lo elimina.
     * Si no existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se elimina ningun Robot.
     *
     * @param location índice de la localización donde se intentará eliminar robot.
     */
    public void removeRobot(int location) {
        boolean removed = robots.removeIf(r -> {
            if (r.getLocation() == location){
                r.makeInvisible();
                return true;
        }
        return false;
        });
        lastOperationOk = removed;
    }
    
    /**
     * Busca un Robot en la ubicación dada y lo mueve.
     * Si no existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se mueve ningun Robot.
     *
     * @param location índice de la localización del Robot que se intentará mover.
     * @param meters cantidad de casillas que avanzara el robot
     */
    public void moveRobot(int location, int meters) {
    int finallocation = location + meters;
    if (finallocation >= length || finallocation < 0) {
        lastOperationOk = false;
        return;
    }

    for (Robot r : robotMovements) {
        if (r.getLocation() == location) {
            r.makeMove(meters, this.length);

            for (Store s : stores) {
                if (s.getLocation() == r.getLocation() && s.getTenges() > 0 && s.canBeCollected(r)) {
                    int collected = s.collect(r.type());
                    int distance = Math.abs(location - finallocation);
                    int gain = collected - distance;
                    profit += Math.max(gain, 0);
                    r.addGain(location, Math.max(gain, 0));
                    if (showing){
                    bar.update(profit, maximumTenge);
                    }
                }
            }

            lastOperationOk = true;
            return; 
        }
    }
    lastOperationOk = false;
    }
    
    /**
     * Busca un Robot en la ubicación dada y lo mueve paso por paso dando la sensacion de que se ahce paso por paso.
     * Si no existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se mueve ningun Robot.
     *
     * @param location índice de la localización del Robot que se intentará mover.
     * @param meters cantidad de casillas que avanzara el robot
     */
    public void moveRobotSlow(int location, int meters) {
    int finallocation = location + meters;
    if (location + meters >= length || location + meters < 0) {
        lastOperationOk = false;
        return;
        }
        for (Robot r : robotMovements) {
        if (r.getLocation() == location) {
            r.makeMoveSlow(meters, this.length);

            for (Store s : stores) {
                if (s.getLocation() == r.getLocation() && s.getTenges() > 0 && s.canBeCollected(r)) {
                    int collected = s.collect(r.type());
                    int distance = Math.abs(location - finallocation);
                    int gain = collected - distance;
                    profit += Math.max(gain, 0);
                    r.addGain(location, Math.max(gain, 0));
                    bar.update(profit, maximumTenge);
                }
            }

            lastOperationOk = true;
            return;
        }
    }
    lastOperationOk = false;
    }
    
    /**
     * Busca un Robot en la ubicación dada y calcula su mejor movimiento
     * Si no existe un Robot en esa posición o la localización es inválida,
     * la operación falla y no se mueve ningun Robot.
     *
     * @param location índice de la localización del Robot que se intentará mover.
     * 
     */
    public void moveRobotOptimized(int location) {
        if (location >= length || location < 0) {
            lastOperationOk = false;
            return;
        }
        for (Robot r : robotMovements) {
            if (r.getLocation() == location) {
                int meters = r.calculateBestMove(stores);
                int finallocation = location + meters;
                r.makeMove(meters, this.length);
                for (Store s : stores) {
                    if (s.getLocation() == r.getLocation() && s.getTenges() > 0 && s.canBeCollected(r)) {
                        int collected = s.collect(r.type());
                        int distance = Math.abs(location - finallocation);
                        int gain = collected - distance;
                        profit += Math.max(gain, 0);
                        r.addGain(location, Math.max(gain, 0));
                        bar.update(profit, maximumTenge);
                    }
                }
                lastOperationOk = true;
                return;
            }
        }
        lastOperationOk = false;
        }
    
    /**
     * Todos los Robots que se hayan creados vuelven a su posicion de origen (donde fueron creados).
     *
     */
    public void returnRobots() {
        for (Robot r : robots) {
            r.graphicReset();
        }
        if (showing){
            bar.update(profit, maximumTenge);
        }
        lastOperationOk = true;
        }
    
    /**
     * Todos los Robots que se hayan creados vuelven a su posicion de origen (donde fueron creados), las tiendas se reabastecen (Se reinicia el tenge) y se reinicia el profit (profit = 0).
     *
     */ 
    public void reboot() {
        profit = 0;
        returnRobots();
        resupplyStores();
        if (showing){
            bar.update(profit, maximumTenge);
        }
        lastOperationOk = true;
        }
    
    /**
     * Termina la simulacion, oculta el tablero y  finaliza la Máquina Virtual de Java.
     *
     */ 
    public void finish() {
        makeInvisible();
        System.exit(0);
    }

    /**
     * Devuelve el profit
     *
     */ 
    public int getProfit() {
        return profit;
    }
    /**
     * Contruye una matriz bidimensional de enteros que representa una lista de tiendas donde arr[i][0] es la localizacion de la tienda y arr[i][1] es el tenge de dicha tienda.
     * @return arr la matriz creada.
     */
    public int[][] stores() {
        int[][] arr = new int[stores.size()][2];
        stores.sort(Comparator.comparingInt(Store::getLocation));
        for (int i = 0; i < stores.size(); i++) {
            arr[i][0] = stores.get(i).getLocation();
            arr[i][1] = stores.get(i).getTenges();
        }
        return arr;
    }
    
    /**
     * Contruye una matriz bidimensional de enteros que representa una lista de robots donde arr[i][0] es la localizacion de origen del Robot y arr[i][1] es el localizacion actual del Robot.
     * @return arr la matriz creada.
     */
    public int[][] robots() {
        int[][] arr = new int[robots.size()][2];
        robots.sort(Comparator.comparingInt(Robot::getInitialLocation));
        for (int i = 0; i < robots.size(); i++) {
            arr[i][0] = robots.get(i).getInitialLocation();
            arr[i][1] = robots.get(i).getLocation();
        }
        return arr;
    }
    
    /**
     * Evalua si la ultima operacion fue correcta.
     * @return lastOperationOk si el valor es verdadero fue correcto si es falso es invalido.
     */

    public boolean ok() {
        return lastOperationOk;
    }
    
    
    /**
    * Calcula el valor maximo en una matriz de enteros
    * @param arr Una matriz 2D de enteros (int[][]) que contiene los valores a evaluar.
    * @return El valor máximo encontrado en la matriz.
    */
    private int max2D(int[][] arr) {
    int max = Integer.MIN_VALUE;
    for (int i = 0; i < arr.length; i++) {
        for (int j = 0; j < arr[i].length; j++) {
            if (arr[i][j] > max) {
                max = arr[i][j];
            }
        }
    } 
    return max;
    }

    
    /**
     * Genera un color valido y aleatorio para shapes.
     * @return color devuelve el color generado.
     */
    private String randomColor() {
        if (availableColors.isEmpty()) {
            Collections.addAll(availableColors,
                "red", "blue", "yellow", "green", "magenta",
                "orange", "pink", "cyan", "gray", "light_gray", "dark_gray",
                "brown", "gold", "lime", "teal", "navy", "salmon",
                "orchid", "coral", "aquamarine", "turquoise", "alice_blue",
                "crimson", "deep_pink", "chartreuse");
        }
        Random random = new Random();
        int index = random.nextInt(availableColors.size());
        String color = availableColors.get(index);
        availableColors.remove(index);

        return color;
    }
    
    /**
     * Devuelve la cantidad de veces que una tienda especificada ha sido vaciada.
     * @param location ubicacion de la tienda
     * @return times de veces que la tienda especificada ha sido vaciada
     * return -1 si la locacion de la tienda es invalida (no exite o fuera de rango)
     */
    public int timesStoreEmptied(int location) {
    for (Store s : stores) {
        if (s.getLocation() == location) {
            lastOperationOk = true;
            int times = s.getEmptiedCount();
            return times;
        }
    }
    lastOperationOk = false;
    return -1;

    }  
    
    /**
     * Devuelve la una lista de elementos Tupla que contiene cantidad de ganacias de un robot especificado (ubicacion donde se obtuvo, cantidad de ganancia).
     * @param location ubicacion del robot
     * @return times de veces que la tienda especificada ha sido vaciada
     * return null si la locacion del robot es invalida (no exite o fuera de rango)
     */
    public List<Tupla> especificRobotGains(int location){
        for (Robot r: robots){
            if (r.getLocation() == location){
                lastOperationOk = true;
                return r.getGains();
            }
        }
        lastOperationOk = false;
        return null;
    }
    
    
    /**
     * Crea una lista bidimencional que contiene arr[i][0] la ubicacion de la tienda y arr[i][1] las veces que ha sido vaciada.
     * @return arr lista int[][] de todas las tiendas.
     * 
     */
    public int[][] emtiedStores() {
        int[][] arr = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            arr[i][0] = stores.get(i).getLocation();
            arr[i][1] = stores.get(i).getEmptiedCount();
        }
        return arr;
    }
    
    /**
     * Crea una lista bidimencional que contiene arr[i][0] la ubicacion del robot y arr[i][j + 1] todas las ganancias que ha conseguido hasta el momento.
     * @return arr lista int[][] de todas las tiendas.
     * 
     */
    public int[][] profitPerMove() {
    int maxGains = 0;
    for (Robot r : robots) {
        maxGains = Math.max(maxGains, r.getGains().size());
    }
    
    int[][] arr = new int[robots.size()][1 + maxGains];

    for (int i = 0; i < robots.size(); i++) {
        
        arr[i][0] = robots.get(i).getInitialLocation();

        List<Tupla> gains = robots.get(i).getGains();
        for (int j = 0; j < gains.size(); j++) {
            arr[i][j + 1] = gains.get(j).getSecond();
        }
    }
    return arr; 
    }
    

    
    /**
     * Inicia un hilo que hace brillar al robot con más ganancias.
     * Cambia su color constantemente con el efecto Starman mientras el juego esté mostrando.
     */
   public void shinyRobot() {
  
    }
    
    public Store getStoreAt(int location){
        for (Store s : stores){
            if (s.getLocation() == location){
                return s;
            }
        }
        return null;
    }
        
    
    /**
     * Todos los robots deciden su mejor movimiento.
     * 
     */
    public void moveRobots() {
    if (robots.isEmpty()) {
        lastOperationOk = false;
        return;
    }
    int activeStores = 0;
    for (Store s : stores) {
    if (s.getTenges() > 0) {
        activeStores++;
    }
    }
    for (int round = 0; round < activeStores; round++) {
        boolean anyMovedThisRound = false;
        
        Collections.sort(robots, (r1, r2) -> {
            int d1 = r1.distanceToNearestStore(stores);
            int d2 = r2.distanceToNearestStore(stores);
            return Integer.compare(d1, d2);
        });
        
        for (Robot r : robots) {
            int meters = r.calculateBestMove(stores);

            if (meters != 0) {
                moveRobot(r.getLocation(), meters);
                anyMovedThisRound = true;
            }else if (r.type().equals("Friendly") || r.type().equals("Tender") && meters == 0) {
                Store currentStore = getStoreAt(r.getLocation());
                if (currentStore.getTenges() > 0 && currentStore != null ) {
                    moveRobot(r.getLocation(), meters);
                    anyMovedThisRound = true;
                }
            }
        }

        if (!anyMovedThisRound) {
            break;
        }
    }
    lastOperationOk = true;
    }
    
    /**
     * Todos los robots deciden su mejor movimiento y se meuven lento (casilla por casilla)
     * 
     */
    public void moveRobotsSlow() {
    if (robots.isEmpty()) {
        lastOperationOk = false;
        return;
    }

    lastOperationOk = true;

    int activeStores = 0;
    for (Store s : stores) {
        if (s.getTenges() > 0) { 
            activeStores++;
    }
    }
    
    for (int round = 0; round < activeStores; round++) {
        boolean anyMovedThisRound = false;

        for (Robot r : robots) {
            int meters = r.calculateBestMove(stores);
            if (meters != 0) {
                moveRobotSlow(r.getLocation(), meters);
                anyMovedThisRound = true;
            }
        }

        if (!anyMovedThisRound) break;
    }
    }
    
    
    /**
     * Aumenta el nivel de zoom del lienzo (Canvas).
     * 
     * Este método llama a la función `zoomIn()` del objeto Canvas,
     * permitiendo acercar la vista para observar detalles más precisos.
     */
    public void zoomIn(){
        Canvas.getCanvas().zoomIn();
    }
    
    /**
     * Disminuye el nivel de zoom del lienzo (Canvas).
     * 
     * Este método llama a la función `zoomOut()` del objeto Canvas,
     * permitiendo alejar la vista para tener una perspectiva más amplia.
     */
    public void zoomOut(){
        Canvas.getCanvas().zoomOut();
    }
}
    