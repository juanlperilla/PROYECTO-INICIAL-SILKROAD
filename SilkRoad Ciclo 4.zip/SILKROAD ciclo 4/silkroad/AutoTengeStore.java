package silkroad;
import shapes.Triangle;


/**
 * Representa una tienda Fighter (Solo los robots con mas tenge que ella puede recolectar) dentro del simulador Silk Road.
 * 
 * Cada tienda tiene una ubicación, una cantidad de tenges (moneda del juego),
 * una representación gráfica compuesta por un rectángulo (cuerpo) y un triángulo (techo),
 * y puede ser recolectada, reiniciada, movida gráficamente y cambiar de color.
 * 
 * @author (Juan Lizarazo) 
 * @version (1.0)
 */
public class AutoTengeStore extends Store{
    private Triangle detail;

    /**
     * Crea una FightStore en una ubicación específica con una cantidad inicial de tenges.
     * 
     * @param location Posición de la tienda en la ruta.
     * @param tenges Cantidad inicial de tenges disponibles en la tienda.
     * @param size tamaño total del tablero.
     */
    public AutoTengeStore(int location, int tenges, int size){
        super(location, (int)(Math.random() * ((int)(Math.random() * 100))), size);
    }
    
    
    /**
     * Mueve gráficamente la tienda a una posición en la cuadrícula.
     * 
     * @param row Fila en la cuadrícula.
     * @param col Columna en la cuadrícula.
     */
    @Override
    public void graphicMove(int row, int col){
    if (detail == null) {
        this.detail = new Triangle();
        detail.changeColor("black");
        detail.changeSize(30, 30);
        detail.moveHorizontal(123);
        detail.moveVertical(35);
    }
    super.graphicMove(row, col);
    detail.moveHorizontal(123+250*col);
    detail.moveVertical(35+250*row);
    }
    
    /**
     * Hace visible la tienda en el lienzo.
     */
    @Override
    public void makeVisible() {
    super.makeVisible();
    detail.makeVisible();
    }
    
    /**
     * Oculta la tienda del lienzo.
     */

    @Override
    public void makeInvisible() {
    super.makeInvisible();
    detail.makeInvisible();
    }
    
    /**
     * Cambia el color gráfico de la tienda.
     * 
     * @param color Nuevo color a aplicar.
     */
    @Override
    public void changeColor(String color){
    super.changeColor(color);
    detail.changeColor("black");
    }
}