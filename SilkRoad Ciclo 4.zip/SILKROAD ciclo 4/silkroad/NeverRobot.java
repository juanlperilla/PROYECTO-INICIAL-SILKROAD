package silkroad;

import shapes.Circle;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A class that contains Robot methods for silkroad.
 * 
 * @author (Juan Camilo Lizarazo) 
 * @version (1.0)
 * Representa un robot NeverBack dentro del juego SilkRoad.  
 *
 * Cada robot NeverBack tiene una posición inicial y actual, un registro de ganancias obtenidas
 * y una representación gráfica compuesta por varias figuras geométricas (cabeza, cuerpo, brazos y piernas).
 * </p>
 *
 * 
 * El robot puede moverse (Solo se muieve hacia atras), calcular su mejor movimiento en función de las tiendas disponibles,
 * y actualizar su color o visibilidad en el entorno gráfico.
 * 
 */
public class NeverRobot extends Robot{
    private Circle detail;
    /**
     * Crea un nuevo robot (NeverBack) en la ubicación especificada.
     *
     * @param location posición inicial del robot en la carretera de la seda.
     */
    public NeverRobot(int location){
        super(location);
        detail = new Circle();
        detail.changeColor("black");
        detail.changeSize(30);
        detail.moveHorizontal(110);
        detail.moveVertical(160);
    }
    /**
     * Mueve gráficamente al robot hacia la celda especificada por fila y columna.
     * 
     * Las coordenadas se transforman en posiciones absolutas dentro del entorno gráfico.
     * 
     *
     * @param row la fila a la que se desea mover el robot.
     * @param col la columna a la que se desea mover el robot.
     */
    @Override
    public void graphicMove(int row, int col){
        super.graphicMove(row, col);
        detail.moveHorizontal(110+250*col);
        detail.moveVertical(160+250*row);
    }
    /**
     * Oculta el robot del lienzo.
     */

    @Override
    public void makeInvisible() {
    super.makeInvisible();
    detail.makeInvisible();
    }
    /**
     * Hace visible el robot  en el lienzo.
     */
    @Override
    public void makeVisible() {
    super.makeVisible();
    detail.makeVisible();
    }
    
    /**
     * Calcula el mejor movimiento posible del robot basándose en las tiendas disponibles.
     * 
     * Evalúa todas las posibles rutas con posicion mayor a la del robot y determina aquella que maximiza la ganancia total,
     * considerando la distancia y los tenges disponibles en cada tienda.
     * 
     *
     * @param stores lista de tiendas disponibles con su ubicación y tenges.
     * @return el desplazamiento (en metros) que debe realizar el robot para obtener el máximo beneficio,
     *         o {@code 0} si no hay un movimiento rentable.
     */
    @Override
    public int calculateBestMove(List<Store> stores) {
        int pos = this.getLocation();
        int bestMove = 0;
        int bestTotalProfit = Integer.MIN_VALUE;
        int bestDistance = Integer.MAX_VALUE;
    
        for (Store s : stores) {
            int sLoc = s.getLocation();
            int sTenges = s.getTenges();
    
            if (sTenges <= 0 || sLoc <= pos) continue;
    
            int distToS = sLoc - pos;
            int immediate = sTenges - distToS;
    
            if (immediate < 0) continue;
    
            Map<Integer, Integer> tempStock = new HashMap<>();
            for (Store t : stores) tempStock.put(t.getLocation(), t.getTenges());
    
            int totalProfit = immediate;
            tempStock.put(sLoc, 0);
            int curPos = sLoc;
    
            while (true) {
                int bestContGain = Integer.MIN_VALUE;
                int bestContLoc = -1;
    
                for (Map.Entry<Integer, Integer> e : tempStock.entrySet()) {
                    int loc = e.getKey();
                    int stock = e.getValue();
    
                    if (stock <= 0 || loc <= curPos) continue;
    
                    int d = loc - curPos; 
                    int gain = stock - d;
    
                    if (gain > bestContGain) {
                        bestContGain = gain;
                        bestContLoc = loc;
                    }
                }
    
                if (bestContGain > 0) {
                    totalProfit += bestContGain;
                    tempStock.put(bestContLoc, 0);
                    curPos = bestContLoc;
                } else {
                    break;
                }
            }
    
            if (totalProfit > bestTotalProfit ||
                (totalProfit == bestTotalProfit && distToS < bestDistance)) {
                bestTotalProfit = totalProfit;
                bestMove = sLoc - pos;
                bestDistance = distToS;
            }
        }
    
        return (bestTotalProfit > 0) ? bestMove : 0;
    }
    
    /**
     * Calcula la distancia a la tienda más cercana que tenga al menos un tenge disponible en posiciones mayores a la del robot actual.
     *
     * <p>Este método recorre la lista de tiendas proporcionada y calcula la distancia absoluta
     * entre la ubicación actual del robot y la ubicación de cada tienda que tenga {@code tenges > 0}.
     * Retorna la menor de estas distancias. Si ninguna tienda cumple con la condición,
     * retorna {@code 0}.</p>
     *
     * @param stores una lista de objetos {@code Store} que representan las tiendas disponibles
     * @return la distancia mínima a una tienda con tenges disponibles, o {@code 0} si no hay ninguna
     */
    @Override
    public int distanceToNearestStore(List<Store> stores) {
        int minDist = Integer.MAX_VALUE;
        int pos = this.getLocation();
        for (Store s : stores) {
            int sLoc = s.getLocation();
            if (s.getTenges() > 0 && sLoc > pos) {
                int dist = sLoc - pos;
                if (dist < minDist){ 
                    minDist = dist;
                }   
            }
        }
        return (minDist == Integer.MAX_VALUE) ? 0 : minDist;
    } 
    
    /**
     * Realiza un movimiento instantáneo del robot si se encuentra en la ubicación especificada.
     *
     * <p>Este método calcula la nueva posición del robot sumando los metros al valor de {@code location} donde si los metros son negativos se volveran positivos {@code meters * -1}.
     * Luego convierte esa posición a coordenadas gráficas y actualiza la visualización mediante {@code graphicMove}.
     * Finalmente, actualiza la posición lógica del robot con {@code move(meters)}.</p>
     *
     * @param location la ubicación actual esperada del robot
     * @param meters la cantidad de unidades que debe moverse el robot
     * @param length la longitud de la cuadrícula o mapa para convertir posiciones a coordenadas
     */
    @Override
    public void makeMove(int meters, int length){
        if (meters < 0){
            meters = Math.abs(meters);
        }
        int finallocation = this.getLocation() + meters;
        int[] cords = positionToCoords(finallocation, length);
        graphicMove(cords[0], cords[1]);
        move(meters);
    }
    
    /**
     * Realiza un movimiento animado paso a paso del robot si se encuentra en la ubicación especificada.
     *
     * <p>Este método simula el movimiento del robot de forma gradual, actualizando su posición gráfica
     * en cada paso desde {@code location} hasta {@code location + meters} donde si los metros son negativos se volveran positivos {@code meters * -1}. La dirección del movimiento
     * se determina por el signo de {@code meters}. Al finalizar, se actualiza la posición lógica del robot
     * con {@code move(meters)}.</p>
     *
     * @param location la ubicación actual esperada del robot
     * @param meters la cantidad de unidades que debe moverse el robot (puede ser negativa)
     * @param length la longitud de la cuadrícula o mapa para convertir posiciones a coordenadas
     */
    @Override
    public void makeMoveSlow(int meters, int length){
        if (meters < 0){
            meters = meters * -1;
        }
        int finalLocation = this.getLocation() + meters;
        int step = (meters > 0) ? 1 : -1;
        int currentStep = this.getLocation();
        while (currentStep != finalLocation) {
            currentStep += step;
            int[] cords = positionToCoords(currentStep, length);
            graphicMove(cords[0], cords[1]);
            }
        move(meters);
    }
}