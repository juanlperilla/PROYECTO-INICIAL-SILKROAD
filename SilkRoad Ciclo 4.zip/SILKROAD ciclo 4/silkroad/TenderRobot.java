package silkroad;
import shapes.Rectangle;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 * A class that contains Robot methods for silkroad.
 * 
 * @author (Juan Camilo Lizarazo) 
 * @version (1.0)
 * Representa un robot Tender dentro del juego SilkRoad.  
 *
 * Cada robot Tender tiene una posición inicial y actual, un registro de ganancias obtenidas. Solo puede recolectar la mitad de monedas (tenges) de una tienda, 
 * y una representación gráfica compuesta por varias figuras geométricas (cabeza, cuerpo, brazos y piernas).
 * </p>
 *
 * 
 * El robot puede moverse, calcular su mejor movimiento en función de las tiendas disponibles,
 * y actualizar su color o visibilidad en el entorno gráfico.
 * 
 */
public class TenderRobot extends Robot{
    private Rectangle detail;
    /**
     * Crea un nuevo robot (TenderRobot) en la ubicación especificada.
     *
     * @param location posición inicial del robot en la carretera de la seda.
     */
    public TenderRobot(int location){
        super(location);
        detail = new Rectangle();
        detail.changeColor("black");
        detail.changeSize(30, 30);
        detail.moveHorizontal(110);
        detail.moveVertical(158);
    }
    /**
     * Mueve gráficamente al robot hacia la celda especificada por fila y columna.
     * 
     * Las coordenadas se transforman en posiciones absolutas dentro del entorno gráfico.
     * 
     *
     * @param row la fila a la que se desea mover el robot.
     * @param col la columna a la que se desea mover el robot.
     */
    @Override
    public void graphicMove(int row, int col){
        super.graphicMove(row, col);
        detail.moveHorizontal(110+250*col);
        detail.moveVertical(158+250*row);
    }
    /**
     * Oculta el robot del lienzo.
     */

    @Override
    public void makeInvisible() {
    super.makeInvisible();
    detail.makeInvisible();
    }
    /**
     * Hace visible el robot  en el lienzo.
     */
    @Override
    public void makeVisible() {
    super.makeVisible();
    detail.makeVisible();
    }
    
    /**
     * Devuelve que tipo de robots es 
     *
     *@return String "Normal" Robot Normal.
     */
    @Override
    public String type(){
        return "Tender";
    }
    


}