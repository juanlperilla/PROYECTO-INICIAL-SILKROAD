package silkroad; 

import javax.swing.JOptionPane;
import java.util.*;
import javax.swing.*;
import java.util.Scanner;

/**
 * Clase principal de consola gráfica para controlar el simulador Silk Road.
 * 
 * Esta clase permite al usuario interactuar con el juego mediante una serie de opciones
 * presentadas en cuadros de diálogo. Se pueden colocar/eliminar tiendas y robots,
 * moverlos, consultar estadísticas, reiniciar el juego, y controlar el zoom del tablero.
 * 
 * @author Juan Camilo Lizarazo
 * @version 1.0
 */

public class MainConsole {
    
    /**
     * Inicia el menú interactivo del simulador Silk Road.
     * 
     * @param game Instancia del juego SilkRoad que se va a controlar.
     */

    public static void start(SilkRoad game) {
        boolean running = true;
        while (running) {
            String opcion = JOptionPane.showInputDialog(
                "--- SIMULADOR SILK ROAD ---\n" +
                "⚠ALERTA:Las posiciones se manejan desde 0 hasta la longitud del tablero menos 1(n-1)⚠\n"+
                "1. Colocar tienda\n" +
                "2. Eliminar tienda\n" +
                "3. Colocar robot\n" +
                "4. Eliminar robot\n" +
                "5. Mover robot\n" +
                "6. Reabastecer tiendas\n" +
                "7. Regresar robots\n" +
                "8. Reiniciar (Se reinicia al estado inicia: Reabastecer tiendas , Regresar robots, profit = 0)\n"+
                "9. Ver estado del juego\n" +
                "10. Ver profit total\n" +
                "11. Ver número de veces que una tienda ha sido desocupada\n"+
                "12. Ver ganancias que ha logrado un robot en cada movimiento\n"+
                "13. Dejar que el robot calcule el mejor movimiento\n"+
                "14. Dejar que los robots calculen su mejor movimiento\n"+
                " + . Zoom In\n"+
                " - . Zoom Out\n"+
                "0. Salir");
        

            switch (opcion) {
                case "1":
                    int locStore;
                    int money;
                    String tipo = ""; 
                    while (!tipo.equals("0") && !tipo.equals("1") && !tipo.equals("2") && !tipo.equals("3")) {
                        tipo = JOptionPane.showInputDialog(
                            "Seleccione el tipo de tienda:\n" +
                            "0. Normal\n" +
                            "1. Autonomous\n" +
                            "2. Fighter\n" +
                            "3. Automatic Tenges\n");
                    
                        if (!tipo.equals("0") && !tipo.equals("1") && !tipo.equals("2") && !tipo.equals("3")) {
                            JOptionPane.showMessageDialog(null, "Opción inválida. Por favor ingrese 0, 1 o 2.");
                        }
                    }
                    switch (tipo){
                        case "0":
                            locStore = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda:"));
                            money = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de tenges:"));
                            game.placeStore(locStore, money, tipo);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Tienda colocada." : "Error: posición ocupada o fuera de rango.");
                            break;
                        case "1":
                            locStore = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda:"));
                            money = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de tenges:"));
                            game.placeStore(locStore, money, tipo);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Tienda colocada." : "Error: posición ocupada o fuera de rango.");
                            break;
                        case "2":
                            locStore = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda:"));
                            money = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de tenges:"));
                            game.placeStore(locStore, money, tipo);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Tienda colocada." : "Error: posición ocupada o fuera de rango.");
                            break;
                        case "3":
                            locStore = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda:"));
                            money = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de tenges:"));
                            game.placeStore(locStore, money, tipo);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Tienda colocada." : "Error: posición ocupada o fuera de rango.");
                            break;
                    }
                    break;  
                case "2":
                    int locStoreDel = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda a eliminar:"));
                    game.removeStore(locStoreDel);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Tienda eliminada." : "No se encontró tienda.");
                    break;
                case "3":
                    int locRobot;
                    String tipe = ""; 
                    while (!tipe.equals("0") && !tipe.equals("1") && !tipe.equals("2") && !tipe.equals("3")) {
                        tipe = JOptionPane.showInputDialog(
                            "Seleccione el tipo de tienda:\n" +
                            "0. Normal\n" +
                            "1. Neverback\n" +
                            "2. Tender\n"+
                            "3. Friendly\n");
                    
                        if (!tipe.equals("0") && !tipe.equals("1") && !tipe.equals("2") && !tipe.equals("3")) {
                            JOptionPane.showMessageDialog(null, "Opción inválida. Por favor ingrese 0, 1 o 2 o 3.");
                        }
                    }
                    switch (tipe){
                        case "0":
                            locRobot = Integer.parseInt(JOptionPane.showInputDialog("Posición del Robot:"));
                            game.placeRobot(locRobot, tipe);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Robot colocado." : "Error: ya existe robot allí o esta fuera de rango.");
                            break;
                        case "1":
                            locRobot = Integer.parseInt(JOptionPane.showInputDialog("Posición del Robot:"));
                            game.placeRobot(locRobot, tipe);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Robot colocado." : "Error: ya existe robot allí o esta fuera de rango.");
                            break;
                        case "2":
                            locRobot = Integer.parseInt(JOptionPane.showInputDialog("Posición del Robot:"));
                            game.placeRobot(locRobot, tipe);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Robot colocado." : "Error: ya existe robot allí o esta fuera de rango.");
                            break;
                        case "3":
                            locRobot = Integer.parseInt(JOptionPane.showInputDialog("Posición del Robot:"));
                            game.placeRobot(locRobot, tipe);
                            JOptionPane.showMessageDialog(null, game.ok() ? "Robot colocado." : "Error: ya existe robot allí o esta fuera de rango.");
                            break;    
                    }
                    break;
                case "4":
                    int locRobotDel = Integer.parseInt(JOptionPane.showInputDialog("Posición actual del robot a eliminar:"));
                    game.removeRobot(locRobotDel);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Robot eliminado." : "No se encontró robot.");
                    break;
                case "5":
                    int locMove = Integer.parseInt(JOptionPane.showInputDialog("Posición actual del robot a mover:"));
                    int steps = Integer.parseInt(JOptionPane.showInputDialog("Número de pasos a mover:"));
                    game.moveRobot(locMove, steps);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Robot movido." : "No se encontró robot o se intento mover fuera de rango..");
                    break;
                case "6":
                    game.resupplyStores();
                    JOptionPane.showMessageDialog(null, "Todas las tiendas han sido reabastecidas.");
                    break;
                case "7":
                    game.returnRobots();
                    JOptionPane.showMessageDialog(null, "Todos los robots regresaron a su posición inicial.");
                    break;
                case "8":
                    game.reboot();
                    JOptionPane.showMessageDialog(null, "Todos los robots regresaron a su posición inicial, Todas las tiendas han sido reabastecidas y el profit se reinicia a 0.");
                    break;
                case "9":
                    StringBuilder estado = new StringBuilder("--- Estado del juego ---\n");
                    estado.append("Profit actual: ").append(game.getProfit()).append("\n\n");

                    estado.append("Tiendas:\n");
                    int[][] tiendas = game.stores();
                    for (int[] t : tiendas) {
                        estado.append(" - Posición ").append(t[0]).append(" con ").append(t[1]).append(" tenges\n");
                    }

                    estado.append("\nRobots:\n");
                    int[][] robots = game.robots();
                    for (int[] r : robots) {
                        estado.append(" - Robot inicial en ").append(r[0])
                              .append(" actualmente en ").append(r[1]).append("\n");
                    }

                    JOptionPane.showMessageDialog(null, estado.toString());
                    break;
                case "10":
                    JOptionPane.showMessageDialog(null, "Profit total: " + game.getProfit());
                    break;
                case "11":
                    int locStoreforCon = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda a consultar:"));
                    int timesUnoccupied = game.timesStoreEmptied(locStoreforCon);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Veces desocupada: " + timesUnoccupied : "Error: La tienda no existe o fuera de rango.");
                    break;
                case "12":
                    int locRobotforCon = Integer.parseInt(JOptionPane.showInputDialog("Posición del Robot a consultar:"));
                    List<Tupla> ganancias = game.especificRobotGains(locRobotforCon);
                    if (ganancias == null){
                        JOptionPane.showMessageDialog(null, "Lo siento el robot en esta ubicacion no existe");
                    }
                    StringBuilder ganancia = new StringBuilder("--- Ganancias del Robot en "+locRobotforCon+"---\n");
                    for (Tupla t : ganancias)  {
                        ganancia.append(" - En la Posición: ").append(t.getFirst()).append(" se gano ").append(t.getSecond()).append(" tenges\n");
                    }
                    JOptionPane.showMessageDialog(null, ganancia.toString());
                    break;
                case "13":
                    int locMoveR = Integer.parseInt(JOptionPane.showInputDialog("Posición actual del robot que decidira:"));
                    game.moveRobotOptimized(locMoveR);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Robot movido." : "No se encontró robot o se intento mover fuera de rango..");
                    break;
                case "14":
                    game.moveRobots();
                    JOptionPane.showMessageDialog(null, game.ok() ? "Todos los robots realizaron su mejor movimiento": "No hay robots para mover...");
                    break;
                case "+":
                    game.zoomIn();
                    JOptionPane.showMessageDialog(null, "Se acerco el tablero");
                    break;
                case "-":
                    game.zoomOut();
                    JOptionPane.showMessageDialog(null, "Se alejo el tablero");
                    break;
                case "0":
                    running = false;
                    game.finish();
                    JOptionPane.showMessageDialog(null, "Simulación terminada.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");

    
            }
        }
    }

        
}
