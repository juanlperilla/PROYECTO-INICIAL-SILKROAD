package shapes;
/**
 * Interface Unit
 * 
 * @author (Juan Lizarazo) 
 * @version (1.0)
 */

public interface Unit
{
    /**
     * Make this unit visible. If it was already visible, do nothing.
     */
    void makeVisible();
    

    /**
     * Make this triangle invisible. If it was already invisible, do nothing.
     */
     void makeInvisible();
    
    
}