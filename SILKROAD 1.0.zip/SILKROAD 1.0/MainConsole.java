
/**
 * Write a description of class MainConsole here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;

public class MainConsole {
    public static void start(SilkRoad game) {
        boolean running = true;
        while (running) {
            String opcion = JOptionPane.showInputDialog(
                "--- SIMULADOR SILK ROAD (MODO CONSOLA) ---\n" +
                "⚠ALERTA:Las posiciones se manejan desde 0 hasta la longitud del tablero menos 1⚠\n"+
                "1. Colocar tienda\n" +
                "2. Eliminar tienda\n" +
                "3. Colocar robot\n" +
                "4. Eliminar robot\n" +
                "5. Mover robot\n" +
                "6. Reabastecer tiendas\n" +
                "7. Regresar robots\n" +
                "8. Reiniciar (Reabastecer tiendas y Regresar robots)\n"+
                "9. Ver estado del juego\n" +
                "10. Ver profit total\n" +
                "0. Salir"
            );
           
            if (opcion == null) break;

            switch (opcion) {
                case "1":
                    int locStore = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda:"));
                    int money = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de tenges:"));
                    game.placeStore(locStore, money);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Tienda colocada." : "Error: posición ocupada o fuera de rango.");
                    break;
                case "2":
                    int locStoreDel = Integer.parseInt(JOptionPane.showInputDialog("Posición de la tienda a eliminar:"));
                    game.removeStore(locStoreDel);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Tienda eliminada." : "No se encontró tienda.");
                    break;
                case "3":
                    int locRobot = Integer.parseInt(JOptionPane.showInputDialog("Posición del robot:"));
                    game.placeRobot(locRobot);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Robot colocado." : "Error: ya existe robot allí o esta fuera de rango.");
                    break;
                case "4":
                    int locRobotDel = Integer.parseInt(JOptionPane.showInputDialog("Posición actual del robot a eliminar:"));
                    game.removeRobot(locRobotDel);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Robot eliminado." : "No se encontró robot.");
                    break;
                case "5":
                    int locMove = Integer.parseInt(JOptionPane.showInputDialog("Posición actual del robot a mover:"));
                    int steps = Integer.parseInt(JOptionPane.showInputDialog("Número de pasos a mover:"));
                    game.moveRobot(locMove, steps);
                    JOptionPane.showMessageDialog(null, game.ok() ? "Robot movido." : "No se encontró robot.");
                    break;
                case "6":
                    game.resupplyStores();
                    JOptionPane.showMessageDialog(null, "Todas las tiendas han sido reabastecidas.");
                    break;
                case "7":
                    game.returnRobots();
                    JOptionPane.showMessageDialog(null, "Todos los robots regresaron a su posición inicial.");
                    break;
                case "8":
                    game.reboot();
                    JOptionPane.showMessageDialog(null, "Todos los robots regresaron a su posición inicial y Todas las tiendas han sido reabastecidas.");
                case "9":
                    StringBuilder estado = new StringBuilder("--- Estado del juego ---\n");
                    estado.append("Profit actual: ").append(game.profit()).append("\n\n");

                    estado.append("Tiendas:\n");
                    int[][] tiendas = game.stores();
                    for (int[] t : tiendas) {
                        estado.append(" - Posición ").append(t[0]).append(" con ").append(t[1]).append(" tenges\n");
                    }

                    estado.append("\nRobots:\n");
                    int[][] robots = game.robots();
                    for (int[] r : robots) {
                        estado.append(" - Robot inicial en ").append(r[0])
                              .append(" actualmente en ").append(r[1]).append("\n");
                    }

                    JOptionPane.showMessageDialog(null, estado.toString());
                    break;
                case "10":
                    JOptionPane.showMessageDialog(null, "Profit total: " + game.profit());
                    break;
                case "0":
                    running = false;
                    game.finish();
                    JOptionPane.showMessageDialog(null, "Simulación terminada.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        }
    }

        
}
