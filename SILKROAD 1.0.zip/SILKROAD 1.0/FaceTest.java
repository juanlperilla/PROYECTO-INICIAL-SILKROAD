
/**
 * se dibuja una figura utilizando CIrcle y Rectangl
 * 
 * @author Juan Angel Salas - Juan Lizarazo 
 * @version (1.1)
 */
public class FaceTest
{
    // instance variables - replace the example below with your own
    Rectangle face;
    Circle pointOne;
    Circle pointTwo;
    Circle pointThree;

    public FaceTest() {
        // Aquí va todo el código que me mostraste
        face = new Rectangle();
        pointOne = new Circle();
        pointTwo = new Circle();
        pointThree = new Circle();

        face.changeColor("black");
        face.changeSize(195, 195);
        face.makeVisible();

        pointOne.changeColor("yellow");
        pointOne.moveHorizontal(70);
        pointOne.moveVertical(20);

        pointTwo = pointOne;
        pointTwo.changeColor("red");
        pointTwo.moveHorizontal(180);
        pointTwo.moveVertical(150);
        pointTwo.makeVisible();

        pointThree = new Circle();
        pointThree.moveHorizontal(120);
        pointThree.moveVertical(90);
        pointThree.makeVisible();

        pointOne.makeVisible();
    }
}