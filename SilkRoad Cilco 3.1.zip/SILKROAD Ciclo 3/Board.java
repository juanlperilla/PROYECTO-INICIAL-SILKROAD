
/**
 * Creates a set of cells organized as a board for games.
 * 
 * @author (Juan Camilo Lizarazo) 
 * @version (1.0)
 */
public class Board implements Unit{
    private int size;       
    private Cell[][] cells; 

    /**
     * Constructor del tablero.
     * 
     * @param size Tamaño del tablero (número de filas y columnas).
     */

    public Board(int size) {
        this.size = size;
        cells = new Cell[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                int x = j * Cell.SIZE;
                int y = i * Cell.SIZE;
                
                cells[i][j] = new Cell("white", x, y);
            }
        }
    }

    /**
     * Hace visible todas las celdas del tablero.
     */
    @Override
    public void makeVisible() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cells[i][j].makeVisible();
            }
        }
    }
    /**
     * Oculta todas las celdas del tablero.
     */
    @Override
    public void makeInvisible() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cells[i][j].makeInvisible();
            }
        }
    }
    
    /**
     * Devuelve la celda en una posición específica del tablero.
     * 
     * @param row Fila de la celda.
     * @param col Columna de la celda.
     * @return La celda ubicada en (row, col).
     */
    public Cell getCell(int row, int col) {
        return cells[row][col];
    }
}
