

/**
 * Clase que inicia el simulador Silk Road en modo gráfico.
 * 
 * Esta clase activa la visualización del juego y luego lanza el menú interactivo
 * para controlar el simulador mediante opciones gráficas.
 * 
 * @author Juan Camilo Lizarazo
 * @version 1.0
 */
public class MainGraphics {
    
    /**
    * Inicia el modo gráfico del simulador Silk Road.
    * 
    * @param game Instancia del juego SilkRoad que se va a visualizar y controlar.
    */
    public static void start(SilkRoad game) {
        game.makeVisible();
        MainConsole.start(game);
    }
}