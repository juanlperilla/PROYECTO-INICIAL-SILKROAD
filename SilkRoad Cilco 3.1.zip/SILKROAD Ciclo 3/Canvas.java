import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;
import java.awt.geom.AffineTransform;

/**
 * Canvas is a class to allow for simple graphical drawing on a canvas.
 * This is a modification of the general purpose Canvas, specially made for
 * the BlueJ "shapes" example.
 *
 * @author: Bruce Quig
 * @author: Michael Kolling (mik)
 * @version: 1.6 (shapes)
 */
public class Canvas {
    private static Canvas canvasSingleton;
    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private List<Object> objects;
    private HashMap<Object, ShapeDescription> shapes;
    private double scaleFactor = 1.0;   

     static Canvas getCanvas() {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas("BlueJ Shapes Demo", 2000, 1000, Color.white);
        }
        canvasSingleton.setVisible(true);
        return canvasSingleton;
    }  

    private Canvas(String title, int width, int height, Color bgColour) {
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList<Object>();
        shapes = new HashMap<Object, ShapeDescription>();
    }

    public void setVisible(boolean visible) {
        if (graphic == null) {
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D) canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    public void draw(Object referenceObject, String color, Shape shape) {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }

    public void erase(Object referenceObject) {
        objects.remove(referenceObject);
        shapes.remove(referenceObject);
        redraw();
    }

    public void setForegroundColor(String colorString) {
        switch (colorString.toLowerCase()) {
            case "red": graphic.setColor(Color.red); break;
            case "black": graphic.setColor(Color.black); break;
            case "blue": graphic.setColor(Color.blue); break;
            case "yellow": graphic.setColor(Color.yellow); break;
            case "green": graphic.setColor(Color.green); break;
            case "magenta": graphic.setColor(Color.magenta); break;
            case "white": graphic.setColor(Color.white); break;
            case "orange": graphic.setColor(Color.orange); break;
            case "pink": graphic.setColor(Color.pink); break;
            case "cyan": graphic.setColor(Color.cyan); break;
            case "gray": graphic.setColor(Color.gray); break;
            case "light_gray": graphic.setColor(Color.lightGray); break;
            case "dark_gray": graphic.setColor(Color.darkGray); break;
            case "brown": graphic.setColor(new Color(165, 42, 42)); break;
            case "gold": graphic.setColor(new Color(255, 215, 0)); break;
            case "lime": graphic.setColor(new Color(0, 255, 0)); break;
            case "teal": graphic.setColor(new Color(0, 128, 128)); break;
            case "navy": graphic.setColor(new Color(0, 0, 128)); break;
            case "salmon": graphic.setColor(new Color(250, 128, 114)); break;
            case "orchid": graphic.setColor(new Color(218, 112, 214)); break;
            case "coral": graphic.setColor(new Color(255, 127, 80)); break;
            case "aquamarine": graphic.setColor(new Color(127, 255, 212)); break;
            case "turquoise": graphic.setColor(new Color(64, 224, 208)); break;
            case "alice_blue": graphic.setColor(new Color(240, 248, 255)); break;
            case "crimson": graphic.setColor(new Color(220, 20, 60)); break;
            case "deep_pink": graphic.setColor(new Color(255, 20, 147)); break;
            case "chartreuse": graphic.setColor(new Color(127, 255, 0)); break;
            default: graphic.setColor(Color.black);
        }
    }

    public void wait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (Exception e) {
            // ignoring exception at the moment
        }
    }

    private void redraw() {
    erase();

    AffineTransform originalTransform = graphic.getTransform();

    graphic.scale(scaleFactor, scaleFactor);

    for (Iterator i = objects.iterator(); i.hasNext(); ) {
        shapes.get(i.next()).draw(graphic);
    }

    graphic.setTransform(originalTransform);

    canvas.repaint();
    }


    private void erase() {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
        }

    private class CanvasPane extends JPanel {
        public void paint(Graphics g) {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }

    private class ShapeDescription {
        private Shape shape;
        private String colorString;

        public ShapeDescription(Shape shape, String color) {
            this.shape = shape;
            colorString = color;
        }

        public void draw(Graphics2D graphic) {
            setForegroundColor(colorString);
            graphic.draw(shape);
            graphic.fill(shape);
        }
    }
    
    public void zoomOut() {
    if (scaleFactor > 0.1) {
        scaleFactor -= 0.1;
        redraw();
        }   
    }
    
    public void zoomIn() {
    scaleFactor += 0.1;
    redraw();
    }

}
