
import javax.swing.*;
import java.util.*;

/**
 * Clase de consola para ejecutar simulaciones del juego SilkRoad.
 * 
 * Esta clase permite leer datos desde la entrada estándar (consola),
 * construir la matriz de eventos y ejecutar la simulación visual.
 * 
 * @author Juan Camilo Lizarazo
 * @version 1.0
 */

public class MarathonConsole {
    
    /**
     * Inicia la simulación leyendo datos desde la consola.
     * 
     * El formato esperado es:
     * - Un número entero `n` que indica la cantidad de días.
     * - Luego `n` líneas con eventos, donde cada línea contiene:
     *   - Tipo 1: `1 <posición>` para agregar un robot.
     *   - Tipo 2: `2 <posición> <ganancia>` para agregar una tienda.
     * 
     * @param slow Si es true, activa el modo de simulación lenta.
     */

    public static void start(boolean slow) {
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    sc.nextLine();

    int[][] matrix = new int[n][];

    for (int i = 0; i < n; i++) {
        String line = sc.nextLine().trim();
        if (line.isEmpty()) {
            i--;
            continue;
        }

        String[] parts = line.split("\\s+");
        matrix[i] = new int[parts.length];

        for (int j = 0; j < parts.length; j++) {
            matrix[i][j] = Integer.parseInt(parts[j]);
        }
    }

    sc.close();
    SilkRoadContest.simulate(matrix, slow);
    try{
        Thread.sleep(10000);
    } catch(InterruptedException e){
        e.printStackTrace();
    }
    System.out.println("Terminando...");
    System.exit(0);
    }   
    
    
}


